(* :Title: Manifolds *)

(* :Context: Morphology`Manifolds` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is the foundation of the directory Morphology.
    Usual operations on manifolds are defined here or in loaded
    subpackages. *)
    
(* :Keywords: morphology, form, shape, manifold, variety, 
	CAD, shape design, form synthesis *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version 
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References: 

	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 *)



BeginPackage["Morphology`Manifolds`",
	{
	"Morphology`Manifolds`Datatypes`",
	"Morphology`Manifolds`Draw`",
    "Morphology`Manifolds`Mappings`",
	
	"Morphology`Transformations`",
	"Morphology`Coordinates`"
	}];

Patch::Usage = "";
Coordinates::Usage = "";
Dim::Usage = "";
Codim::Usage = "";

ToAtlas::Usage = "";
Standardize::Usage = "";

UnitHyperCube::Usage = "";
UnitSimplex::Usage = "";
UnitBall::Usage = "";

Lift::Usage = "";
MapLift::Usage = "";
Slice::Usage = "";
Sides::Usage = "";  
Boundary::Usage = "";
Movie::Usage = "";
Homotopy::Usage = "";
VectorInterpolatingPolynomial::Usage = "";
ManifoldInterpolation::Usage = "";



If[$VersionNumber < 6, 
	Remove[Morphology`Manifolds`Mappings`Animation];
	DeclarePackage["Graphics`Animation`", {"Animate"}]
  ] (* for command Movie *)



Begin["`Private`"];


(* ** * Selectors *** *)

Domain[Manifold[_, d___List]] ^:= {d}
Codomain[Manifold[e_, ___]] ^:= e  

Coordinates[Manifold[_, d___List]] ^:= Map[First, {d}]
Coordinates[Manifold[_, d___Symbol]] ^:= {d}

Dim[m_]:= Length[Coordinates[m]]
Codim[m_]:= Length[Codomain[m]]

Manifold[CoordinateSystem[coorsyst_?CoordinateSystemQ]] ^:= 
  Manifold[coorsyst, Apply[Sequence, 
    StandardDomain[CoordinateSystem[coorsyst]]
  ]]
  
ToAtlas[Manifold[s_/;TensorRank[s] > 1,d__]]:=
  Atlas[Map[Manifold[#,d]&,s,{TensorRank[s] - 1}]]

normalizer[{c_, 0, 1}] := c -> c
normalizer[{c_, 0, 1}, p_] := c -> p
normalizer[{c_, cmin_, Infinity}] := c -> (ArcTanh[c] + cmin)
normalizer[{c_, cmin_, Infinity}, p_] := c -> (ArcTanh[p] + cmin)
normalizer[{c_, -Infinity, cmax_}] := c -> (ArcTanh[c - 1] + cmax)
normalizer[{c_, -Infinity, cmax_}, p_] := c -> (ArcTanh[p - 1] + cmax)
normalizer[{c_, -Infinity, Infinity}] := c -> ArcTanh[2c - 1]
normalizer[{c_, -Infinity, Infinity}, p_] := c -> ArcTanh[2p - 1]
normalizer[{c_Symbol, cmin_, cmax_}] := c -> (cmax*c + cmin(1 - c))
normalizer[{c_Symbol, cmin_, cmax_}, p_] := c -> (cmax*p + cmin(1 - p))

Manifold/:Standardize[m : Manifold[e_, d___List]] := 
  Manifold[
  	e /. Map[normalizer, {d}], 
    Apply[Sequence, Thread[List[Coordinates[m], 0, 1]]]
  ]

Manifold/:Standardize[Manifold[e_, d___List], p___Symbol]/;
	Length[{d}] == Length[{p}]:=
  Manifold[
	e /. Thread[normalizer[{d}, {p}]], 
	Apply[Sequence, Thread[List[{p}, 0, 1]]]
  ]



(* *** Automatic simplifications - experimental *** *)

Manifold[p_, u___, {c_, cval_, cval_}, v___]:= 
	Manifold[p /.c -> cval, u, v]



(* *** Primitive manifolds *** *)

UnitHyperCube[s_List]:=Manifold[s,Apply[Sequence,Thread[List[s,0,1]]]]

(* UnitSimplex, UnitBall *)




(* ** * Operations on manifolds *** *)

(* Lifting *)

Lift[m:Manifold[e_/;Head[e]=!=List, d__]]:= 
	Manifold[Append[Coordinates[m], e], d]

Lift[m:Manifold[e_?VectorQ, d__]]:= 
	Manifold[Join[Coordinates[m], e], d]

MapLift[m:Manifold[e_?VectorQ, d__]]:= 
	Manifold[Map[Join[Coordinates[m], {#}]&, e], d]

Lift[m:Manifold[e_/;TensorRank[e] > 1, d__],{n_}]:= 
	Manifold[Map[Join[Coordinates[m], #]&, e, {TensorRank[e]-1}], d]

MapLift[m:Manifold[e_/;TensorRank[e] > 1, d__],{n_}]:= 
	Manifold[Map[Join[Coordinates[m], {#}]&, e, {TensorRank[e]}], d]



(* Slicing *)
(* {p,pmin,pmax,dp:1} *)

Slice[Manifold[e_,v___,{p_,pmin_,pmax_},w___],{p_,n_:2}](*/;MemberQ[e,p]*):=
	Manifold[Table[e,{p,pmin,pmax,(pmax-pmin)/(n-1)}],v,w]
  
Slice[Manifold[e_,v___,{p_,pmin_,pmax_},w___],{p_,var_List}]/;
	MemberQ[e,p]/;Thread[pmin\[LessEqual]var\[LessEqual]pmax]:=
		Manifold[e/.p\[Rule]var,v,w]

Slice[m_Manifold,v__List,w_List]:=Slice[Slice[m,w],v]

Slice[m_Manifold,w_?MatrixQ]:=Atlas[Map[Slice[m,#]&,w]]



(* Sides extraction *)

(* options PlotPoints *)

toMin[{v_, vmin_, _}] := v -> vmin
toMax[{v_, _, vmax_}] := v -> vmax

buildSides[p_][{s_, {d___}}] :=  
  Map[Manifold[#, d] &, 
    p /. Flatten[
        Outer[List, 
          Apply[Sequence, Transpose[{Map[toMin, s], Map[toMax, s]}]]], 
        Length[s] - 1]
    ]

Manifold /: Boundary[m_Manifold] := Sides[m, 1]

Manifold /: Sides[m_Manifold, 0] := m

Manifold /: 
  Sides[Manifold[expr_, domain__], n_:1] /; n <= Length[{domain}] := 
  Atlas[Flatten[Map[buildSides[expr],
        Map[{#, Complement[{domain}, #]} &, Subsets[{domain}, {n}]]
        ]]]

Manifold /: Sides[m_Manifold, n_] /; n > Length[Coordinates[m]] := 
  Sides[m, Length[Coordinates[m]]]



(* Animations *)

Movie[Manifold[e_?VectorQ, d___], tr_, range_List, opt___Rule] /; 
    (MemberQ[tr, First[range], {-1}] && $VersionNumber < 6) := 
  Animate[
  	Draw[Manifold[tr[e], d], 
  		DisplayFunction -> Identity, 
  		Apply[Sequence,Complement[{opt}, {FilterOptions[Animate, opt]}]]
  	], 
  range, FilterOptions[Animate, opt]
  ]



(* Homotopy *)

Homotopy[{p_Symbol, pmin_, pmax_}][e1_, e2_] := 
	(e2(p - pmin) - e1(p - pmax))/(pmax - pmin)

Homotopy[p_][e1_, e2_] := (1 - p) e1 + p e2  


Homotopy[f_, {p_Symbol, pmin_, pmax_}][e1_, e2_] :=
  (e2(f[p] - f[pmin]) - e1(f[p] - f[pmax]))/(f[pmax] - f[pmin])

Homotopy[f_, p_][e1_, e2_] :=
  (e2(f[p] - f[0]) - e1(f[p] - f[1]))/(f[1] - f[0])


Homotopy[f1_, f2_, {p_Symbol, pmin_, pmax_}][e1_, e2_] :=
  e2(f2[p] - f2[pmin])/(f2[pmax] - f2[pmin]) - 
  e1(f1[p] - f1[pmax])/(f1[pmax] - f1[pmin])
  
Homotopy[f1_, f2_, p_][e1_, e2_] :=
  e2(f2[p] - f2[0])/(f2[1] - f2[0]) - 
  e1(f1[p] - f1[1])/(f1[1] - f1[0])

  

(* obsolete 

Manifold/:Homotopy[
		Manifold[e1_, d___], Manifold[e2_, d___], p_Symbol] /; 
		Length[e1] == Length[e2] := 
    Manifold[Homotopy[e1, e2, p], d, {p, 0, 1}]
    
Manifold/:Homotopy[
		Manifold[e1_, d___], Manifold[e2_, d___], p : {_Symbol, _, _}] /; 
    	Length[e1] == Length[e2] := 
    Manifold[Homotopy[e1, e2, p], d, p]

Manifold/:Homotopy[f__][
		Manifold[e1_, d___], Manifold[e2_, d___], p_Symbol] /; 
    	Length[e1] == Length[e2] := 
	Manifold[Homotopy[f][e1, e2, p], d, {p, 0, 1}]
	
Manifold/:Homotopy[f__][
		Manifold[e1_, d___], Manifold[e2_, d___], p : {_Symbol, _, _}]/;
		Length[e1] == Length[e2] := Manifold[Homotopy[f][e1, e2, p], d, p]

Manifold/:Homotopy[
		m1 : Manifold[e1_, d1___], m2 : Manifold[e2_, d2___], p_] /; 
    	Coordinates[m1] == Coordinates[m2] && Length[e1] == Length[e2] := 
	Homotopy[Standardize[m1], Standardize[m2], p]

Manifold/:Homotopy[f__][
		m1 : Manifold[e1_, d1___], m2 : Manifold[e2_, d2___], p_] /; 
		Coordinates[m1] == Coordinates[m2] && Length[e1] == Length[e2] := 
	Homotopy[f][Standardize[m1], Standardize[m2], p]

end obsolete *)



(* Interpolation - experimental *)

ManifoldInterpolation[
  Manifold[e1_, d___], 
  Manifold[e2_, d___], 
  homo_[_,_,p_]
] /; And[Length[e1] == Length[e2], MatchQ[homo, Homotopy|Homotopy[__]]] := 
	Manifold[homo[e1, e2, p], d, {p, 0, 1}]

ManifoldInterpolation[
  Manifold[e1_, d___], 
  Manifold[e2_, d___], 
  homo_[_,_,p : {_Symbol, _, _}]
] /;  And[Length[e1] == Length[e2], MatchQ[homo, Homotopy|Homotopy[__]]] := 
	Manifold[homo[e1, e2, p], d, p]

ManifoldInterpolation[
  m1:Manifold[e1_, d1___], 
  m2:Manifold[e2_, d2___], 
  h_
] /;  And[
  Length[e1] == Length[e2], 
  Coordinates[m1] == Coordinates[m2]
] := 
	ManifoldInterpolation[Standardize[m1], Standardize[m2], h]



VectorInterpolatingPolynomial[s_List, p_Symbol]:=
  Thread[ip[Transpose[Apply[Thread[List[##]]&,s,1]],p]]/.ip->
      InterpolatingPolynomial

extractDomain[{_,Manifold[_,d___]}]:={d}
extractCodomain[{p_,Manifold[cod_,___]}]:= cod
extractCoordinates[{_,m_}]:= Coordinates[m]
extractIndexedCodomain[{p_,Manifold[cod_,___]}]:={p,cod}
indexedStandardize[{p_, m_}]:={p,Standardize[m]}

ManifoldInterpolation[s:{{_,_Manifold}..}, p_Symbol]/;
  And[
	Apply[Equal,Map[extractDomain,s]],
    Apply[Equal,Map[Length,Map[extractCodomain,s]]]
  ]:=
  Manifold[Thread[VectorInterpolatingPolynomial[
  	Map[extractIndexedCodomain,s], p]],
    Apply[Sequence,
      Append[extractDomain[First[s]],{p,First[s][[1]],Last[s][[1]]}]]]

ManifoldInterpolation[s:{{_,_Manifold}..}, p_Symbol]/;
  And[
	Apply[Equal,Map[extractCoordinates,s]],
    Apply[Equal,Map[Length,Map[extractCodomain,s]]]
  ]:=
	ManifoldInterpolation[Map[indexedStandardize,s], p]



(* Geometric domains - experimental *)

h[{v_, v1_, v2_}]:= Homotopy[v][v1, v2]
u[{v_, _, _}]:= {v, 0, 1}

Patch[p_, d1_List] := 
  Manifold[p, d1]

Patch[p_, d1_List, d__List]:=
  Manifold[
	Fold[ReplaceAll, p, 
	  Reverse[Thread[Rule[Map[First, {d1,d}], Map[h, {d1, d}]]]]
	],
    Apply[Sequence, Map[u, {d1, d}]]
  ]
    
    

End[];

Protect[Patch, Coordinates, Dim, Codim, ToAtlas, Standardize, 
UnitHyperCube, UnitSimplex, UnitBall, 
Lift, MapLift, Slice, Sides, Boundary, Movie, Homotopy, 
VectorInterpolatingPolynomial, ManifoldInterpolation];

EndPackage[];
