(* :Title: Fractals *)

(* :Context: Morphology`Fractals` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is complementary component of the directory Manifold.
    Fractals are defined in terms of manifolds. *)
    
(* :Keywords: fractal, fractal manifold, fractal function, 
	iterated function system, IFS *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)
(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References: 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'2006 *)



BeginPackage["Morphology`Fractals`",
			{"Morphology`Manifolds`",
			"Morphology`Common`"}];

ScaleTransform::Usage="";
FractalFunction::Usage="";

IFS::Usage="";
WeightedFunctionSystem::Usage="";
PlayChaosGame::Usage="";

(*
Cantor::Usage="";
SquareCarpet2D::Usage="";
HighlightedSquareCarpet2D::Usage="";
RectangularSierpinski2D::Usage="";
EquilateralSierpinski2D::Usage="";
RectangularSierpinski3D::Usage="";
BarnsleyTexture::Usage="";
BarnsleyFern::Usage="";
BarnsleyTree::Usage="";
*)



Begin["`Private`"];

(* *** Fractal Functions *** *)

ScaleTransform[w_,d_,k_][e_,t_]/;
	And[VectorQ[e],Or[VectorQ[w],VectorQ[d]]]:=
  w^(-k*d)*MapThread[ReplaceAll,{e,Thread[t->w^k*t]}]
    
ScaleTransform[w_,d_,k_][e_,t_]:=w^(-k*d)*(e/.t->w^k*t)
    
FractalFunction[w_,d_,n_][e_,t_]:=
  Sum[ScaleTransform[w,d,k][e,t],{k,0,n}]



(* obsolete 

(* *** Iterated Function Systems *** *)

oneStep[ifs_?VectorQ][s_]:= Flatten[Outer[#1[#2]&, ifs, s, 1], 1]

Spread[ifs_?VectorQ, init_List, n_]:= 
	Nest[oneStep[ifs], {init}, n]

SpreadList[ifs_?VectorQ, init_List, n_]:= 
	Flatten[NestList[oneStep[ifs], {init}, n], 1]

Spread[ifs_?VectorQ, Manifold[p_, c___], n_]:= 
	Manifold[Spread[ifs, p, n], c]

SpreadList[ifs_?VectorQ, Manifold[p_, c___], n_]:= 
	Manifold[SpreadList[ifs, p, n], c]



(* *** Weighted Iterated Function Systems *** *)

oneStep[{ifs_List, weigths_List}][s_]:= 
	Flatten[Outer[#1[#2]&, ifs, s, 1], 1]

Spread[wifs:{_List, _List}, init_, n_]:= 
	Nest[oneStep[wifs], {init}, n]

SpreadList[ifs:{_List, _List}, Manifold[p_, c___], n_]:= 
	Manifold[Spread[ifs, p, n], c]


end obsolete *)



(* *** Chaos Game *** *)

selectFirst[{___,x_,___}, test_]/;test[x]:=x

WeightedFunctionSystem[ifs_List|FunctionSystem[ifs_], weights_List][v_]:=
     With[{p=Random[Real,{0,Total[weights]}]},
      Extract[
          ifs,
          First[Position[
              Rest[FoldList[Plus, 0, weights]],
              selectFirst[FoldList[Plus, 0, weights], #>p &]
              ]]
          ][v]
      ]

PlayChaosGame[wfs_WeightedFunctionSystem, init_, n_, dropped_:30]:=
  NestList[
	wfs, 
	Nest[wfs, init, dropped], 
	n-1
  ]



(* *** Common Iterated Function Systems *** *)

IFS["Cantor"]:= FunctionSystem[{#/3 + 1/3 &, #/3 - 1/3 &}]

IFS["SquareCarpet2D"]:= 
	FunctionSystem[v, {
		v/3 + {1/3,0}, v/3 + {1/3, 1/3}, v/3 + {0, 1/3}, v/3 + {-1/3, 1/3},
		v/3 + {-1/3, 0}, v/3 + {-1/3, -1/3}, v/3 + {0, -1/3}, v/3 + {1/3, -1/3}
	}]

IFS["HighlightedSquareCarpet2D"]:= 
	FunctionSystem[v, {
		v/3 + {2,0}, v/3 + {2, 2}, v/3 + {0, 2}, v/3 + {-2, 2},
		v/3 + {-2, 0}, v/3 + {-2, -2}, v/3 + {0, -2}, v/3 + {2, -2}
	}]

IFS["RectangularSierpinski2D"]:= 
	FunctionSystem[{#/2 &, #/2 + {1/2, 0} &, #/2 + {0, 1/2} &}]

IFS["EquilateralSierpinski2D"]:= 
	FunctionSystem[{
		#/2 + {0, Sqrt[3]/8} &,
		#/2 + {1/4, -Sqrt[3]/8} &,
		#/2 + {-1/4,-Sqrt[3]/8} &
	}]

IFS["RectangularSierpinski3D"]:= 
	FunctionSystem[{
		#/2 &, 
		#/2 + {1/2, 0, 0} &, 
		#/2 + {0, 1/2, 0} &,
		#/2 + {0, 0, 1/2} &
	}]

IFS["BarnsleyTexture"]:= 
	FunctionSystem[{
		#/2 + {1, 1}/2 &,
		#/2 + {1, -1}/2 &,
		#/2 + {-1, 1}/2 &,
		#/2 + {-1, -1}/2 &
	}]

IFS["BarnsleyFern"]:= 
	VectorFunctionSystem[{x, y}, {
		{0, 0.16 y},
		{0.85 x + 0.04 y, -0.04 x + 0.85 y} + {0, 1.6},
		{0.2 x - 0.26 y, 0.23 x + 0.22 y} + {0, 1.6},
		{-0.15 x + 0.28 y, 0.26 x + 0.24 y} + {0, 0.44}
	}]

IFS["BarnsleyTree"]:= 
	VectorFunctionSystem[{x, y}, {
		{0, 0.5 y},
		{0.42 x - 0.42 y, 0.42 x + 0.42 y} + {0, 0.2},
		{0.42 x + 0.42 y, -0.42 x + 0.42 y} + {0, 0.2},
		{0.1 x, 0.1 y} + {0, 0.2}
	}]



(* obsolete 

Cantor[1][v_]:= v/3 + 1/3
Cantor[2][v_]:= v/3 - 1/3



SquareCarpet2D[1][v_]:= v/3 + {1/3,0}
SquareCarpet2D[2][v_]:= v/3 + {1/3, 1/3}
SquareCarpet2D[3][v_]:= v/3 + {0, 1/3}
SquareCarpet2D[4][v_]:= v/3 + {-1/3, 1/3}
SquareCarpet2D[5][v_]:= v/3 + {-1/3, 0}
SquareCarpet2D[6][v_]:= v/3 + {-1/3, -1/3}
SquareCarpet2D[7][v_]:= v/3 + {0, -1/3}
SquareCarpet2D[8][v_]:= v/3 + {1/3, -1/3}



HighlightedSquareCarpet2D[1][v_]:= v/3 + {2,0}
HighlightedSquareCarpet2D[2][v_]:= v/3 + {2, 2}
HighlightedSquareCarpet2D[3][v_]:= v/3 + {0, 2}
HighlightedSquareCarpet2D[4][v_]:= v/3 + {-2, 2}
HighlightedSquareCarpet2D[5][v_]:= v/3 + {-2, 0}
HighlightedSquareCarpet2D[6][v_]:= v/3 + {-2, -2}
HighlightedSquareCarpet2D[7][v_]:= v/3 + {0, -2}
HighlightedSquareCarpet2D[8][v_]:= v/3 + {2, -2}



RectangularSierpinski2D[1][v_]:= v/2
RectangularSierpinski2D[2][v_]:= v/2 + {1/2, 0}
RectangularSierpinski2D[3][v_]:= v/2 + {0, 1/2}



EquilateralSierpinski2D[1][v_]:= v/2 + {0, Sqrt[3]/8}
EquilateralSierpinski2D[2][v_]:= v/2 + {1/4, -Sqrt[3]/8}
EquilateralSierpinski2D[3][v_]:= v/2 + {-1/4,-Sqrt[3]/8}



RectangularSierpinski3D[1][v_]:= v/2
RectangularSierpinski3D[2][v_]:= v/2 + {1/2, 0, 0}
RectangularSierpinski3D[3][v_]:= v/2 + {0, 1/2, 0}
RectangularSierpinski3D[4][v_]:= v/2 + {0, 0, 1/2}



BarnsleyTexture[1][v_]:= v/2 + {1, 1}/2
BarnsleyTexture[2][v_]:= v/2 + {1, -1}/2
BarnsleyTexture[3][v_]:= v/2 + {-1, 1}/2
BarnsleyTexture[4][v_]:= v/2 + {-1, -1}/2



BarnsleyFern[1][{x_, y_}]:= {0, 0.16 y}
BarnsleyFern[2][{x_, y_}]:= {0.85 x + 0.04 y, -0.04 x + 0.85 y} + {0, 1.6}
BarnsleyFern[3][{x_, y_}]:= {0.2 x - 0.26 y, 0.23 x + 0.22 y} + {0, 1.6}
BarnsleyFern[4][{x_, y_}]:= {-0.15 x + 0.28 y, 0.26 x + 0.24 y} + {0, 0.44}



BarnsleyTree[1][{x_, y_}]:= {0, 0.5 y}
BarnsleyTree[2][{x_, y_}]:= {0.42 x - 0.42 y, 0.42 x + 0.42 y} + {0, 0.2}
BarnsleyTree[3][{x_, y_}]:= {0.42 x + 0.42 y, -0.42 x + 0.42 y} + {0, 0.2}
BarnsleyTree[4][{x_, y_}]:= {0.1 x, 0.1 y} + {0, 0.2}

end obsolete *)


Protect[ScaleTransform, FractalFunction, 
		IFS, WeightedFunctionSystem, PlayChaosGame];

End[];

EndPackage[];


