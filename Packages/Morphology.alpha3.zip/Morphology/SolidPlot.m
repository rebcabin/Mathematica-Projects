(* :Title: Solid Plot *)

(* :Context: Morphology`SolidPlot` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    It extends ParametricPlot(3D) to 2D domains and 3D solids. *)
    
(* :Keywords: parametric representations, domains, solids *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References:
 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 *)



BeginPackage["Morphology`SolidPlot`"];

SolidParametricPlot::Usage = "";
SolidParametricPlot3D::Usage = "";
ShadingColor::Usage = "";

Begin["`Private`"];


(*  For transitional version, temporary use 
	of FilterOptions by Roman E. Maeder 
	from package Utilities`FilterOptions`
	instead of loading the package *)

FilterOptions[ command_Symbol, options___ ] :=
	FilterOptions[ First /@ Options[command], options ]

FilterOptions[ opts_List, options___ ] :=
	Sequence @@ Select[ Flatten[{options}], MemberQ[opts, First[#]]& ]



internalDisplayFunction[opt___]:=
	DisplayFunction/.{opt}/.(DisplayFunction->$DisplayFunction)



auxiliary[p_Integer, _] := p
auxiliary[p_List, n_] := p[[n]]

reorder[{{a_, b_}, {c_, d_}}] := {a, b, d, c}



(* SolidParametricPlot - for version 5 -
	superseded by ParametricPlot in version 6 *)

Options[SolidParametricPlot] = 
  Union[DeleteCases[
    Options[ParametricPlot], (PlotPoints -> _)|(PlotStyle -> _)], 
      {PlotPoints -> 10, Shading -> False, 
      ShadingColor -> RGBColor[0.85, 0.81, 0.98]}
  ];

SolidParametricPlot[e : {_, _} /; VectorQ[e], du : {u_, umin_, umax_}, 
    dv : {v_, vmin_, vmax_}, opt___] := 
  internalSolidParametricPlot[e, du, dv, opt]

SolidParametricPlot[e_, du : {u_, umin_, umax_}, dv : {v_, vmin_, vmax_}, 
      opt___] /; (MatchQ[e /. {u -> umin, v -> vmin}, {_, _}] && 
        VectorQ[e /. {u -> umin, v -> vmin}]) := 
  internalSolidParametricPlot[e, du, dv, opt]

SolidParametricPlot[e : {{_, _} ..}, du_, dv_, opt___] := 
  Show[Map[internalSolidParametricPlot[#, du, dv, opt, 
          DisplayFunction -> Identity] &, e],
    DisplayFunction -> internalDisplayFunction[opt]]

SolidParametricPlot[e_, du : {u_, umin_, umax_}, dv : {v_, vmin_, vmax_}, 
      opt___] /; MatchQ[e /. {u -> umin, v -> vmin}, {{_, _} ..}] :=
  Show[Map[internalSolidParametricPlot[#, du, dv, opt, 
          DisplayFunction -> Identity] &, e],
    DisplayFunction -> internalDisplayFunction[opt]]

internalSolidParametricPlot[e_, du : {u_, umin_, umax_}, 
    dv : {v_, vmin_, vmax_}, opt___] :=
 With[{
      pp = PlotPoints /. {opt} /. Options[SolidParametricPlot],
      sh = Shading /. {opt} /. Options[SolidParametricPlot],
      sc = ShadingColor /. {opt} /. Options[SolidParametricPlot]
      },
    Show[Insert[Show[
      ParametricPlot[
         Evaluate[
           e /. Map[List, 
              Thread[u -> 
                  Table[u, {u, umin, 
                      umax, (umax - umin)/(auxiliary[pp, 1] - 1)}]]]], dv,
             PlotPoints -> auxiliary[pp, 2], DisplayFunction -> Identity],
          
      ParametricPlot[
        Evaluate[
          e /. Map[List, 
              Thread[v -> 
                  Table[v, {v, vmin, 
                     vmax, (vmax - vmin)/(auxiliary[pp, 2] - 1)}]]]], du,
             PlotPoints -> auxiliary[pp, 1], DisplayFunction -> Identity],
    Apply[Sequence, 
            DeleteCases[{opt}, 
              (PlotPoints -> _) | (Shading -> _) | (ShadingColor -> _)]],
          DisplayFunction -> Identity],
        If[sh == True,
          Prepend[
            Map[Polygon,
              Map[reorder,
                Partition[
                  Table[e,
                    {u, umin, umax, (umax - umin)/(auxiliary[pp, 1] - 1)},
                    {v, vmin, vmax, (vmax - vmin)/(auxiliary[pp, 2] - 1)}
                    ], {2, 2}, {1, 1}
                  ], {2}
                ], {2}
              ], sc
            ],
          {}
          ],
        {1, 1}],
      DisplayFunction -> (DisplayFunction /. {opt} /. 
            Options[SolidParametricPlot]),
      DisplayFunction -> internalDisplayFunction[opt]
      ]
    ]



(* SolidParametricPlot3D - for both version 5 and 6 *)

auxiliary3D[Automatic, _] := Automatic
auxiliary3D[None, _] := None
auxiliary3D[p_Integer, _] := p
auxiliary3D[p_List, n_] := Delete[p, n]
auxiliary3D[any_, _] := any


prependDirectives[(g:(Graphics|Graphics3D))[w:{__List},opt___], dir_List]:=
	g[Map[Join[dir,#]&, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w_List,opt___], dir_List]:=
	g[Join[dir, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w___], {dir___}]:=
	g[dir, w]
	
prependDirectives[(g:(Graphics|Graphics3D))[w:{__List},opt___], dir_]:=
	g[Map[Prepend[#, dir]&, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w_List,opt___], dir_]:=
	g[Prepend[w, dir], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w___], dir_]:=
	g[dir, w]



Options[SolidParametricPlot3D] = 
    Union[DeleteCases[
    Options[ParametricPlot3D], (PlotPoints -> _)], 
    {PlotPoints -> {15, 15, 15}, PlotStyle->{}}];

SolidParametricPlot3D[e : {_, _, _} /; VectorQ[e], 
	du : {v1_, v1min_, v1max_},
     dv : {v2_, v2min_,
    v2max_}, dw : {v3_, v3min_, v3max_}, opt___] := 
  internalSolidParametricPlot3D[e, du, dv, dw, opt]

SolidParametricPlot3D[e_, du : {u_, umin_, umax_}, dv : {v_, vmin_, vmax_}, 
      dw : {w_, wmin_, wmax_}, opt___] /; 
      (MatchQ[e /. {u -> umin, v -> vmin, w -> wmin}, {_, _, _}] &&
      VectorQ[e /. {u -> umin, v -> vmin, w -> wmin}]) := 
  internalSolidParametricPlot3D[e, du, dv, dw, opt]

SolidParametricPlot3D[e : {{_, _, _} ..}, du_, dv_, dw_, opt___] := 
  Show[Map[
      SolidParametricPlot3D[#, du, dv, dw, opt, 
          DisplayFunction -> Identity] &, e],
    DisplayFunction -> internalDisplayFunction[opt]]

SolidParametricPlot3D[e_, du : {u_, umin_, umax_}, dv : {v_, vmin_, vmax_}, 
      dw : {w_, wmin_, wmax_}, opt___] /; 
    MatchQ[e /. {u -> umin, v -> vmin, w -> wmin}, {{_, _, _} ..}] :=
  Show[Map[internalSolidParametricPlot3D[#, du, dv, dw, opt, 
          DisplayFunction -> Identity] &, e],
    DisplayFunction -> internalDisplayFunction[opt]]

SolidParametricPlot3D[e : {{_, _, _} ..}, du_, dv_, dw_, opt___] := 
  Show[Map[SolidParametricPlot3D[#, du, dv, dw, opt, 
          DisplayFunction -> Identity] &, e],
    DisplayFunction -> internalDisplayFunction[opt]]



internalSolidParametricPlot3D[e_, 
	d1 : {v1_, v1min_, v1max_}, 
    d2 : {v2_, v2min_, v2max_}, 
    d3 : {v3_, v3min_, v3max_}, 
    opt___] /; $VersionNumber < 6 := 
  With[{
    pp = PlotPoints /. {opt} /. Options[SolidParametricPlot3D]
    },
    Show[
     Map[prependDirectives[#, 
     	PlotStyle/.{opt}/.Options[SolidParametricPlot3D]
     	]&,
      {
      ParametricPlot3D[e /. v1 -> v1min,  d2, d3,
        PlotPoints -> auxiliary3D[pp, 1], DisplayFunction -> Identity],
      ParametricPlot3D[e /. v1 -> v1max,  d2, d3,
          PlotPoints -> auxiliary3D[pp, 1], DisplayFunction -> Identity],
      ParametricPlot3D[e /. v2 -> v2min, d1, d3,
          PlotPoints -> auxiliary3D[pp, 2], DisplayFunction -> Identity],
      ParametricPlot3D[e /. v2 -> v2max, d1, d3,
          PlotPoints -> auxiliary3D[pp, 2], DisplayFunction -> Identity],
      ParametricPlot3D[e /. v3 -> v3min, d1, d2,
          PlotPoints -> auxiliary3D[pp, 3], DisplayFunction -> Identity],
      ParametricPlot3D[e /. v3 -> v3max, d1, d2,
          PlotPoints -> auxiliary3D[pp, 3], DisplayFunction -> Identity]
      }
     ],
    Apply[Sequence, 
    	DeleteCases[{opt}, ((PlotPoints -> _) | (PlotStyle -> _))]],
      DisplayFunction -> (DisplayFunction /. {opt} /. 
            Options[SolidParametricPlot3D])
      ]
    ]


internalSolidParametricPlot3D[e_, 
	d1 : {v1_, v1min_, v1max_}, 
    d2 : {v2_, v2min_, v2max_}, 
    d3 : {v3_, v3min_, v3max_}, 
    opt___] /; $VersionNumber >= 6 := 
  With[{
    pp = PlotPoints /. {opt} /. Options[SolidParametricPlot3D],
    mm = Mesh /. {opt} /. Options[SolidParametricPlot3D],
    so = Apply[Sequence, DeleteCases[{FilterOptions[ParametricPlot3D, opt]}, 
	  ((PlotPoints -> _) | (Mesh -> _) | (PlotStyle -> _))]
	]
    },
    Show[
     {
      ParametricPlot3D[e /. v1 -> v1min,  d2, d3, so,
        PlotPoints -> auxiliary3D[pp, 1], 
        Mesh -> auxiliary3D[mm, 1], 
        DisplayFunction -> Identity],
      ParametricPlot3D[e /. v1 -> v1max,  d2, d3, so,
        PlotPoints -> auxiliary3D[pp, 1], 
        Mesh -> auxiliary3D[mm, 1], 
        DisplayFunction -> Identity],
      ParametricPlot3D[e /. v2 -> v2min, d1, d3, so,
        PlotPoints -> auxiliary3D[pp, 2], 
        Mesh -> auxiliary3D[mm, 2], 
        DisplayFunction -> Identity],
      ParametricPlot3D[e /. v2 -> v2max, d1, d3, so,
        PlotPoints -> auxiliary3D[pp, 2], 
        Mesh -> auxiliary3D[mm, 2], 
        DisplayFunction -> Identity],
      ParametricPlot3D[e /. v3 -> v3min, d1, d2, so,
        PlotPoints -> auxiliary3D[pp, 3], 
        Mesh -> auxiliary3D[mm, 3], 
        DisplayFunction -> Identity],
      ParametricPlot3D[e /. v3 -> v3max, d1, d2, so,
        PlotPoints -> auxiliary3D[pp, 3], 
        Mesh -> auxiliary3D[mm, 3], 
        DisplayFunction -> Identity]
      },
    Apply[Sequence, DeleteCases[{FilterOptions[Graphics3D, opt]}, 
	  ((PlotPoints -> _) | (Mesh -> _) | (PlotStyle -> _))]
	],
	PlotRange->All, DisplayFunction -> 
      (DisplayFunction /. {opt} /. Options[SolidParametricPlot3D])
    ]
  ]



End[];

Protect[SolidParametricPlot, SolidParametricPlot3D];

EndPackage[];

