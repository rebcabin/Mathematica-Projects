(* :Title: Transformations *)

(* :Context: Morphology`Transformations` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    Common transformations are defined. *)
    
(* :Keywords: transformation *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References:
 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 *)



BeginPackage["Morphology`Transformations`",
			 "Morphology`Common`"];

Off[General::"spell1"];

Matrix::Usage = "";
Unitary::Usage = "";

Rotation::Usage = "";
Precession::Usage = "";
Nutation::Usage = "";
Rolling::Usage = "";
Pitching::Usage = "";
Winding::Usage = "";
Tilting::Usage = "";
Spinning::Usage = "";
Euler::Usage = "";
Nautical::Usage = "";

Inversion::Usage = "";
Flattening::Usage = "";
Shadowing::Usage = "";
Embedding::Usage = "";
Reflection::Usage = "";
Stretching::Usage = "";

Translation::Usage = "";
RightScrewing::Usage = "";
LeftScrewing::Usage = "";
Similarity::Usage = "";
Shear::Usage = "";
Linear::Usage = "";
Affine::Usage = "";
Permutation::Usage = "";

(*
Sliding
Sliding2D
Planar
Rolling? !!
...
*)

Begin["`Private`"];



(* *** Matrices *** *)

(* Rotations revoir Tilting Spinning *)

Unitary[w_] := w/Norm[w]

tiltingMatrix[{0, 0, c_}] := IdentityMatrix[3]

tiltingMatrix[w:{a_, b_, c_}]:={Unitary[{b, -a, 0}], 
    Unitary[{a*c, b*c, -(a^2 + b^2)}], Unitary[w]}



Matrix[Rotation[a_, ___]]:= 
	MatrixExp[{{0, -a}, {a, 0}}]
  
Matrix[Precession[phi_, ___]]:= 
	{{Cos[phi], -Sin[phi], 0}, {Sin[phi], Cos[phi],0}, {0, 0, 1}}

Matrix[Nutation[theta_, ___]] := {{1, 0, 0}, {0, 
      Cos[theta], -Sin[theta]}, {0, Sin[theta], Cos[theta]}}
      
Matrix[Rolling[theta_, ___]]:= 
	{{1, 0, 0}, {0, Cos[theta], -Sin[theta]}, {0, Sin[theta],  Cos[theta]}}
      
Matrix[Pitching[psi_, ___]]:= (* Tangage *) 
    {{Cos[psi], 0, -Sin[psi]}, {0, 1, 0}, {Sin[psi], 0, Cos[psi]}}
      
Matrix[Winding[phi_, ___]]:= (* Lacet *) 
	{{Cos[phi], -Sin[phi], 0}, {Sin[phi], Cos[phi], 0}, {0, 0, 1}}
      
Matrix[Tilting[w:{_, _, _}, ___]]:= Transpose[tiltingMatrix[w]]
    
Matrix[Spinning[w : {_, _, _}, a_, ___]]:= 
  With[{P = tiltingMatrix[w]}, Transpose[P].Matrix[Precession[a]].P]
  
Matrix[Spinning[{theta_, phi_}, a_, ___]]:= 
  With[{
	P = tiltingMatrix[{ Cos[phi] Cos[theta], Cos[phi] Sin[theta], Sin[phi]}]
  }, 
	Transpose[P].Matrix[Precession[a]].P
  ]
    
Matrix[Euler[psi_, theta_, phi_, ___]]:= 
  Matrix[Precession[phi]].Matrix[Nutation[theta]].Matrix[Precession[psi]]
      
Matrix[Nautical[a_, b_, c_, ___]] := 
  Matrix[Winding[c]].Matrix[Pitching[b]].Matrix[Rolling[a]]



(* projections, shadowing and reflections *)

standardize[v_?VectorQ] := {v}
standardize[m_?MatrixQ] := m

Matrix[Flattening[invariant_, direction_, ___]]/; 
    Det[Join[
      standardize[invariant], 
      standardize[direction]]] == 0:= "message"

Matrix[Flattening[invariant_, direction_,___]]:= 
  With[{
  	inv = standardize[invariant],
	dir =  standardize[direction]
  },
  Dot[
   Transpose[Join[inv, dir]],
	Join[
	  Array[1 &, Length[inv]], 
	  Array[0 &, Length[dir]]
	]*
	Inverse[Transpose[Join[inv, dir]]]
   ]
  ]

Matrix[Shadowing[invariant_, direction_,___]]/; 
    Det[Join[
    	standardize[invariant], 
    	standardize[direction]]] == 0 := "message"

Matrix[Shadowing[invariant_, direction_,___]]:= 
  With[{
  	inv = standardize[invariant],
	dir = standardize[direction]
  },
  Take[
  	Inverse[Transpose[Join[inv, dir]]], 
    Length[inv]
   ]
  ]

Matrix[Embedding[subspace_, ___]]:= 
    Transpose[standardize[subspace]]

Matrix[Reflection[invariant_, direction_,___]]/; 
    Det[Join[
    standardize[invariant], 
    standardize[direction]]] == 0:= "message"

Matrix[Reflection[invariant_, direction_,___]] := 
   With[{
  	inv = standardize[invariant],
	dir = standardize[direction]
  },
  Dot[
  Transpose[Join[inv, dir]],
	Join[
	  Array[1 &, Length[inv]], 
	  Array[-1 &, Length[dir]]
	]*
	Inverse[Transpose[Join[inv, dir]]]
	]
  ]

Matrix[Stretching[_, invariant_, direction_,___]]/; 
    Det[Join[
    	standardize[invariant], 
    	standardize[direction]]] == 0:= "message"

Matrix[Stretching[k_,invariant_, direction_,___]] := 
   With[{
  	inv = standardize[invariant],
	dir = standardize[direction]
  },
  Dot[
  Transpose[Join[inv, dir]],
	Join[
	  Array[1 &, Length[inv]], 
	  Array[k &, Length[dir]]
	]*
	Inverse[Transpose[Join[inv, dir]]]
	]
  ]

Matrix[Permutation[s:{___Integer}]]:=
	Map[ReplacePart[Array[0 &,Length[s]], 1, #]&, s]



(* Other transformations *)



(* ** * Analytical expressions *** *)

Translation[v_][p_List]:= p + v

Rotation[r_?RotationParametersQ, pt_:0][p_List] := 
  Matrix[Rotation[r]].(p - pt) + pt
(* a suivre *)

Rotation[a_, pt_:0][p_List]:= 
  Matrix[Rotation[a]].(p - pt) + pt
  
Precession[phi_, pt_:0][p_List]:= 
	Matrix[Precession[phi]].(p - pt) + pt

Nutation[theta_, pt_:0][p_List]:= 
	Matrix[Nutation[theta]].(p - pt) + pt

Rolling[theta_, pt_:0][p_List]:= 
	Matrix[Rolling[theta]].(p - pt) + pt

Pitching[psi_, pt_:0][p_List]:= 
	Matrix[Pitching[psi]].(p - pt) + pt

Winding[phi_, pt_:0][p_List]:= 
	Matrix[Winding[phi]].(p - pt) + pt

Tilting[{0, 0, c_}, pt_:0][p_List]:= p

Tilting[w : {a_, b_, c_}, pt_:0][p_List]:= 
	Matrix[Tilting[w]].(p - pt) + pt

Spinning[w : {_, _, _}, a_, pt_:0][p_List]:= 
	Matrix[Spinning[w, a]].(p - pt) + pt

Spinning[{theta_, phi_}, a_, pt_:0][p_List] := 
  Matrix[Spinning[{theta, phi}, a]].(p - pt) + pt

Euler[psi_, theta_, phi_, pt_:0][p_List] := 
  Matrix[Euler[psi, theta, phi]].(p - pt) + pt

Nautical[a_, b_, c_, pt_:0][p_List] := 
  Matrix[ Nautical[a, b, c]].(p - pt) + pt

RightScrewing[v_, a_, pt_:0][p_List] := 
  Matrix[Spinning[v, a]].(p - pt) + a v + pt

LeftScrewing[v_, a_, pt_:0][p_List] := 
  Matrix[Spinning[v, - a]].(p - pt) + a v + pt

(* n-D *)

Similarity[k_, pt_:0][p_List] := k*(p - pt) + pt

Inversion[pt_][p_List] := 2pt - p

Flattening[invariant_, direction_, pt_:0][p_List] := 
  Matrix[Flattening[invariant, direction]].(p - pt) + pt

Shadowing[invariant_, direction_, pt_:0][p_List] := 
  Matrix[Shadowing[invariant, direction]].(p - pt) + pt

Embedding[subspace_, pt_:0][p_List]:= 
    Matrix[Embedding[subspace]].p + pt

Reflection[invariant_, direction_, pt_:0][p_List] := 
  Matrix[Reflection[invariant, direction]].(p - pt) + pt

Stretching[k_, invariant_, direction_, pt_:0][p_List] := 
  Matrix[Stretching[k, invariant, direction]].(p - pt) + pt

Affine[m_?MatrixQ][p_List]:= m.p

Affine[m_?MatrixQ, v_?VectorQ][p_List]:= m.p + v 

Permutation[s:{___Integer}][w_]/;Length[s]==Length[w]:=
	Part[w, s]



(* ** * Symbolic combinations of transformations *** *)

(* Experimental - to be extended *)

Rotation[0, pt___]:= Identity
Precession[0, pt___]:= Identity
Nutation[0, pt___]:= Identity
Rolling[0, pt___]:= Identity
Pitching[0, pt___]:= Identity
Winding[0, pt___]:= Identity
Spinning[_, 0, pt___]:= Identity
Tilting[{0, 0, _}, pt___]:= Identity
Similarity[1, pt___]:= Identity



InverseFunction[Translation[t_]]^:= Translation[-t]

InverseFunction[Rotation[a_, pt___]]^:= Rotation[-a, pt]

InverseFunction[Precession[phi_, pt___]]^:= 
	Precession[-phi, pt]

InverseFunction[Nutation[theta_, pt___]]^:= 
	Nutation[-theta, pt]

InverseFunction[Rolling[theta_, pt___]]^:= 
	Rolling[-theta, pt]

InverseFunction[Pitching[psi_, pt___]]^:= 
	Pitching[-psi, pt]

InverseFunction[Winding[phi_, pt___]]^:= 
	Winding[-phi, pt]

InverseFunction[Tilting[w : {a_, b_, c_}, pt___]]^:= 
	Tilting[Inverse[tiltingMatrix[w]].{a, b, c}, pt] (* vvv *)

InverseFunction[Spinning[w : {_, _, _}, a_, pt___]]^:= 
	Spinning[w, -a, pt]

InverseFunction[Spinning[{theta_, phi_}, a_, pt___]]^:= 
 Spinning[{theta, phi}, a, pt]

InverseFunction[Euler[psi_, theta_, phi_, pt___]]^:= 
 Euler[-phi, -theta, -psi, pt]

InverseFunction[Nautical[a_, b_, c_, pt___]]^:= 
  Composition[Winding[-c, pt], Pitching[-b, pt], Rolling[-a, pt]]

InverseFunction[Screwing[v_, a_, pt___]]^:= 
  Screwing[-v, -a, pt]

(* n-D *)

InverseFunction[Similarity[k_, pt___]]^:= Similarity[1/k, pt]

InverseFunction[Inversion[pt_]]^:= Inversion[pt]

(* InverseFunction[Flattening[___]]^:= Message[ ] *)
  
(* InverseFunction[Shadowing[___]]^:= Message[ ] *)
  
(* InverseFunction[Embedding[___]]^:= to do *)
  
InverseFunction[Reflection[invariant_, direction_, pt___]]^:= 
Reflection[invariant, direction, pt]

InverseFunction[Stretching[k_, invariant_, direction_, pt___]]^:= 
 Stretching[1/k, invariant, direction, pt]

InverseFunction[Affine[m_?MatrixQ]]^:= Affine[Inverse[m]]

InverseFunction[Affine[m_?MatrixQ, v_?VectorQ]]^:= 
	 Affine[Inverse[m], -Inverse[m].v]



Composition[Translation[t1_], Translation[t2_]]^:=
	Translation[t1 + t2]

Composition[Rotation[a_, pt___], Rotation[b_, pt___]]^:=
	Rotation[a + b, pt]

Composition[Precession[a_, pt___], Precession[b_, pt___]]^:=
	Precession[a + b, pt]

Composition[Nutation[a_, pt___], Nutation[b_, pt___]]^:=
	Nutation[a + b, pt]

Composition[Rolling[a_, pt___], Rolling[b_, pt___]]^:=
	Rolling[a + b, pt]

Composition[Pitching[a_, pt___], Pitching[b_, pt___]]^:=
	Pitching[a + b, pt]

Composition[Winding[a_, pt___], Winding[b_, pt___]]^:=
	Winding[a + b, pt]

Composition[Spinning[w_, a_, pt___], Spinning[w_, b_, pt___]]^:=
	Spinning[w, a + b, pt]

Composition[Screwing[u_, a_, pt___], Screwing[v_, b_, pt___]]^:=
	Screwing[a + b, pt] /; 
	  Apply[And,Thread[Simplify[Cross[u, v]]=={0,0,O}]]

Composition[Similarity[k_, pt___], Similarity[h_, pt___]]^:=
	Similarity[k h, pt]

Composition[Inversion[pt_], Inversion[pt_]]^:= Identity

Composition[Reflection[inv_, dir_, pt___], 
	Reflection[inv_, dir_, pt___]]^:= Identity

Composition[Affine[m_?MatrixQ, u___?VectorQ], 
			Affine[p_?MatrixQ, v_?VectorQ]]^:=
	Affine[m.p, m.v + u]



End[];

On[General::"spell1"];

(* Protect *)

EndPackage[];
