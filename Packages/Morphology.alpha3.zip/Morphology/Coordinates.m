(* :Title: Coordinates *)

(* :Context: Morphology`Coordinates` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is a component of the directory Morphology.
    It is shared (loaded) by Manifolds`.Usual coordinate systems 
    are defined as transformations (vector functions). *)
    
(* :Keywords: manifold, coordinate, coordinate system, 
	vector analysis, tensor analysis, field *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library (see text file named
    gnu-lgpl.txt); if not, write to the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)
(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References: 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'2006 *)



BeginPackage["Morphology`Coordinates`",
				"Morphology`Manifolds`"];

CoordinateSystemQ::Usage = ""; 
CoordinateSystem::Usage = "";
StandardDomain::Usage = "";

Scaling::Usage = "";

Cartesian::Usage = "";
Polar::Usage = "";
InversePolar::Usage = "";
Cylindrical::Usage = "";
InverseCylindrical::Usage = "";
Spherical::Usage = "";
InverseSpherical::Usage = "";
CoSpherical::Usage = "";
InverseCoSpherical::Usage = "";

Oblique::Usage = "";
InverseOblique::Usage = "";

RadialElliptic::Usage = "";
InverseRadialElliptic::Usage = "";
RadialEllipsoidal::Usage = "";
InverseRadialEllipsoidal::Usage = "";
RadialConical::Usage = "";
InverseRadialConical::Usage = "";

(* to be continued *)


Begin["`Private`"];

SetAttributes[CoordinateSystemQ, HoldFirst] 

CoordinateSystemQ[_Cartesian |
	_Polar | _InversePolar |
	_Cylindrical | _InverseCylindrical |
	_Spherical | _InverseSpherical |
	_CoSpherical _InverseCoSpherical |
	_Oblique | _InverseOblique |
	_RadialElliptic| _InverseRadialElliptic |
	_RadialEllipsoidal | _InverseRadialEllipsoidal |
	_RadialConical | _InverseRadialConical
	]:= True
CoordinateSystemQ[___] := False 

SetAttributes[CoordinateSystem, HoldFirst]

(* other definitions in Manifolds` *)



(* common  *)

Scaling[s_List][w_]:= Inner[#1[#2]&, s, w, List]

Cartesian := Identity

StandardDomain[CoordinateSystem[Cartesian[w_]]]^:= 
	Map[{#, -Infinity, Infinity}&, w]



InverseFunction[Polar] ^:= InversePolar
InverseFunction[InversePolar] ^:= Polar

Polar[{r_, t_}] := {r Cos[t], r Sin[t]}

StandardDomain[CoordinateSystem[Polar[{r_, t_}]]]^:= 
	{{r, 0, Infinity}, {t, 0, 2 Pi}}

InversePolar[{0, 0}] := {0, 0}
InversePolar[{u_, v_}] := {Sqrt[u^2 + v^2], ArcTan[u, v]}

StandardDomain[CoordinateSystem[InversePolar[{u_, v_}]]]^:= 
	{{u, -Infinity, Infinity}, {v, -Infinity, Infinity}}



InverseFunction[Cylindrical] ^:= InverseCylindrical
InverseFunction[InverseCylindrical] ^:= Cylindrical

Cylindrical[{r_, t_, h_}] := {r Cos[t], r Sin[t], h}

StandardDomain[CoordinateSystem[Cylindrical[{r_, t_, h_}]]] ^:=
	{{r, 0, Infinity}, {t, 0, 2 Pi}, {h, -Infinity, Infinity}}

InverseCylindrical[{0, 0, w_}] := {0, 0, w}
InverseCylindrical[{u_, v_, w_}]:= 
	{Sqrt[u^2 + v^2], ArcTan[u, v], w}

StandardDomain[CoordinateSystem[InverseCylindrical[{u_, v_, w_}]]]^:= 
	{{u, -Infinity, Infinity}, 
	{v, -Infinity, Infinity}, 
	{w, -Infinity, Infinity}}



InverseFunction[Spherical] ^:= InverseSpherical
InverseFunction[InverseSpherical] ^:= Spherical

Spherical[{r_, theta_, phi_}] := 
	{r Cos[phi] Cos[theta],
	r Cos[phi] Sin[theta], 
	r Sin[phi]}

StandardDomain[CoordinateSystem[Spherical[{r_, theta_, phi_}]]]^:= 
    {{r, 0, Infinity}, {theta, 0, 2 Pi}, {phi, -Pi/2, Pi/2}}

InverseSpherical[{0, 0, 0}] := {0, 0, 0}

InverseSpherical[{0, 0, w_}] := {Abs[w], 0, Sign[w]*Pi/2}

InverseSpherical[{u_, v_, w_}]:= 
	{Sqrt[u^2 + v^2 + w^2], 
	  ArcTan[u, v],
	  ArcSin[w/Sqrt[u^2 + v^2 + w^2]] 
	}

StandardDomain[CoordinateSystem[InverseSpherical[{u_, v_, w_}]]]^:= 
	{{u, -Infinity, Infinity}, 
	{v, -Infinity, Infinity}, 
	{w, -Infinity, Infinity}}



InverseFunction[CoSpherical] ^:= InverseCoSpherical
InverseFunction[InverseCoSpherical] ^:= CoSpherical

CoSpherical[{r_, phi_, theta_}]:= 
	{r Sin[phi] Cos[theta], r Sin[phi] Sin[theta], r Cos[phi]}

StandardDomain[CoordinateSystem[CoSpherical[{r_, theta_, phi_}]]]^:= 
    {{r, 0, Infinity}, {theta, 0, 2 Pi}, {phi, 0, Pi}}

InverseCoSpherical[{0, 0, 0}] := {0, 0, 0}

InverseCoSpherical[{0, 0, w_}] := {Abs[w], 0, ArcTan[Sign[w],0]}

InverseCoSpherical[{u_, v_, w_}]:= 
	{Sqrt[u^2 + v^2 + w^2], 
	 ArcCos[w/Sqrt[u^2 + v^2 + w^2]], 
	 ArcTan[u, v]}

StandardDomain[CoordinateSystem[InverseCoSpherical[{u_, v_, w_}]]]^:= 
	{{u, -Infinity, Infinity}, 
	{v, -Infinity, Infinity}, 
	{w, -Infinity, Infinity}}



InverseFunction[Oblique] ^:= InverseOblique
InverseFunction[InverseOblique] ^:= Oblique

Oblique[m_?MatrixQ][c_]:=m.c  (* cristallography *)

StandardDomain[CoordinateSystem[Oblique[_][c_]]]^:= 
	Map[{#, -Infinity, Infinity}&, c]

InverseOblique[m_?MatrixQ][c_]:= 
	Oblique[Inverse[m]][c]



(* non classical 2D *)

InverseFunction[RadialElliptic[{a_, b_}]] ^:= 
	InverseRadialElliptic[{a, b}]
InverseFunction[InverseRadialElliptic[{a_, b_}]] ^:= 
	RadialElliptic[{a, b}]

RadialElliptic[{a_, b_}][{r_, theta_}]:= 
	{a r Cos[theta], b r Sin[theta]}

StandardDomain[CoordinateSystem[RadialElliptic[{r_, theta_}]]]^:=
	{{r, 0, Infinity}, {theta, 0, 2 Pi}}

InverseRadialElliptic[{a_, b_}][{u_, v_}]:= 
	{Sqrt[(u/a)^2 + (v/b)^2], ArcTan[b u, a v]}



(* non classical 3D *)

InverseFunction[RadialEllipsoidal[{a_, b_, c_}]] ^:= 
	InverseRadialEllipsoidal[{a, b, c}]
InverseFunction[InverseRadialEllipsoidal[{a_, b_, c_}]] ^:= 
	RadialEllipsoidal[{a, b, c}]

RadialEllipsoidal[{a_, b_, c_}][{r_, theta_, phi_}]:= 
	{a r Cos[theta] Cos[phi], 
	 b r Sin[theta] Cos[phi], 
	 c r Sin[phi]}

StandardDomain[CoordinateSystem[
	RadialEllipsoidal[{a_, b_, c_}][{r_, theta_, phi_}]
  ]]^:=
	{{r, 0, Infinity}, {theta, 0, 2 Pi}, {phi, - Pi/2, Pi/2}}

InverseRadialEllipsoidal[{a_, b_, c_}][{u_, v_, w_}]:= 
	{Sqrt[(u/a)^2 + (v/b)^2 + (w/c)^2], 
	  ArcTan[b u, a v],
	  ArcSin[w/(c*Sqrt[u^2 + v^2 + w^2])] 
	}



InverseFunction[RadialConical[a_]] ^:= 
	InverseRadialConical[a]
InverseFunction[InverseRadialConical[a_]] ^:= 
	RadialConical[a]

RadialConical[a_][{r_, theta_, h_}]:=
	{r h Cos[theta] Sin[a], 
	 r h Sin[theta] Sin[a], 
     h}

(* to be continued *)

(* Inverses ans their ranges *)

(*
OrthogonalQ
OrthonormalQ
RightHandedQ

HyperbolicElliptic
Conical
Helicoidal
*)



End[];

(* Protect *)

EndPackage[];

