(* :Title: Mappings *)

(* :Context: Morphology`Manifolds`Mappings` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is a component of the directory Morphology`Manifolds.
    Mappings and sheaves are defined. *)
    
(* :Keywords: mapping, sheaf, sheaves, 
	extrude, extrusion, embed, embedding, connect, connection, 
	reshape, reshaping *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)
(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References: *)



BeginPackage["Morphology`Manifolds`Mappings`",
    {
    "Morphology`Manifolds`",
    "Morphology`Manifolds`Datatypes`",
    "Morphology`Manifolds`Draw`",
    "Morphology`Common`"
    }];



Mapping::Usage = "";
Sheaf::Usage = "";  (* experimental *)
Breeding::Usage = "";  (* experimental *)
Parameters::Usage = "";  (* experimental *)

Embed::Usage = "";

Animation::Usage = "";    (* experimental version 6 *)
Manipulation::Usage = ""; (* experimental version 6 *)



Begin["`Private`"];


Parameters[m_Manifold, opt___] := 
  Complement[Cases[Codomain[m], _Symbol, {0, Infinity}, opt], Coordinates[m]]
  


(* ***  Mappings  ***  *)

Domain[Mapping[_, d___]]^:= {d}  (* experimental *)
Codomain[Mapping[tr_, ___]]^:= tr
Parameters[Mapping[_, d___List]] ^:= Map[First, {d}]
Parameters[Mapping[_, d___Symbol]] ^:= {d}



(* Multiple mappings (with common domain) *)

Mapping[tr_?VectorQ, d___][Manifold[p_?VectorQ, c___]]:=
	Manifold[Through[tr[p]], c, d]

Mapping[tr_List/;ArrayDepth[tr] > 1, d___][Manifold[p_?VectorQ, c___]]:=
	Manifold[Map[#[p]&, tr, {ArrayDepth[tr]}], c, d]

Mapping[tr_List/;ArrayDepth[tr] >= 1, d___][
	  Manifold[p_/;ArrayDepth[p] > 1, c___]]:=
	Manifold[Outer[#1[#2]&, tr, p, ArrayDepth[tr], ArrayDepth[p]-1], c, d]

Mapping[tr_List, d___][Atlas[s_]]:=
	Atlas[Map[Mapping[tr, d], s]]



(* Single mappings - also work with FunctionSystem *)

Mapping[tr_, d___][Manifold[p_?VectorQ, c___]]:=
	Manifold[tr[p], c, d]

Mapping[tr_, d___][Manifold[p_/; ArrayDepth[p] > 1, c___]]:=
	Manifold[Map[tr, p, {ArrayDepth[p] - 1}], c, d]

Mapping[tr_, d___][Atlas[s_]]:=
	Atlas[Map[Mapping[tr, d], s]]



(* Sheaves: multiple mappings or mapping systems ; experimental *)

Sheaf[mp:{__Mapping}][m_Manifold]:=
	Atlas[Through[mp[m]]]

Sheaf[mp:{__Mapping}][Atlas[s_]]:=
	Atlas[Flatten[Map[Sheaf[mp], s]/.Atlas -> List]]



(* Mappings of several variables ; experimental *)

Mapping[tr_, d___][m__Manifold]/;
	Apply[Equal, Map[Domain, {m}]]:=
  Manifold[
	tr[Apply[Sequence, Map[Codomain, {m}]]], 
	Apply[Sequence, Domain[First[{m}]]],
	d
  ]

Breeding[tr_, trd_, d___][m__Manifold]:=
  Manifold[
	tr[Apply[Sequence, Map[Codomain, {m}]]], 
	trd[Apply[Sequence, Map[Domain, {m}]]],
	d
  ]



(* **  Compositions  ** *)


toMapping[m_Mapping]:= m

toMapping[m_Sheaf]:= m

toMapping[m:Manifold[p_?VectorQ, ___]]:= 
	Mapping[VectorFunction[Evaluate[Coordinates[m]], p]]

toMapping[m:Manifold[p_/; ArrayDepth[p] > 1, ___]]:= 
	Mapping[Map[
	  VectorFunction[Evaluate[Coordinates[m]], #]&, 
	  p, 
	  {ArrayDepth[p] - 1}
	]]



(* Declared compositions ; experimental - many-valued atlas *)

Composition[Mapping[tr2_, d2___], Mapping[tr1_, d1___]]/;
		And[ArrayDepth[tr2] >= 1, ArrayDepth[tr1] >= 1]^:=
	Mapping[Outer[Composition, tr2, tr1], d1, d2]

Composition[
	  Mapping[tr2_/;ArrayDepth[tr2] >= 1, d2___], 
	  Mapping[tr1_, d1___]
	]^:=
	Mapping[Map[Composition[#, tr1]&, tr2, {ArrayDepth[tr2]}], d1, d2]

Composition[
	  Mapping[tr2_, d2___], 
	  Mapping[tr1_/;ArrayDepth[tr1] >= 1, d1___]
	]^:=
	Mapping[Map[Composition[tr2, #]&, tr1, {ArrayDepth[tr1]}], d1, d2]
	
Composition[Mapping[tr2_, d2___], Mapping[tr1_, d1___]]^:=
	Mapping[Composition[tr2, tr1], d1, d2]

Composition[Sheaf[mp:{__Mapping}], m_Mapping]^:=
	Sheaf[Map[Composition[#, m]&, mp]]

Composition[m_Mapping, Sheaf[mp:{__Mapping}]]^:=
	Sheaf[Map[Composition[m, #]&, mp]]

Composition[Sheaf[mp1:{__Mapping}], Sheaf[mp2:{__Mapping}]]^:=
	Sheaf[Flatten[Outer[Composition, mp1, mp2]]]



(* Effective compositions with undocumented Compose - experimental *)

HoldPattern[Compose[u___, v_Manifold, w___, m:(_Manifold|_Atlas)]]^:=
  Apply[Compose, Append[Map[toMapping, {u, v, w}], m]]
	(* test Manifold or Mapping *)



(* *** Embed (embeddings, connections, reshapings) ***  *)

Embed[carrier_Manifold, w___, m:(_Manifold|_Atlas)]:=
  Apply[Compose, Append[Map[toMapping, {carrier, w}], m]]
  (* test dims *)

    

(* ***  Animations and manipulations (experimental for version 6)  ***  *)

Domain[Animation[_, d___]]^:= {d} 
Codomain[Animation[tr_, ___]]^:= tr
Parameters[Animation[_, d___List]] ^:= Map[First, {d}]

Domain[Manipulation[_, d___]]^:= {d} 
Codomain[Manipulation[tr_, ___]]^:= tr
Parameters[Manipulation[_, d___List]] ^:= Map[First, {d}]



Animation[tr_, d__List,opt___Rule][m:(_Manifold|_Atlas)]/; 
		$VersionNumber >= 6 :=
	Animate[Draw[Mapping[tr][m]], d]

Manipulation[tr_, d__List,opt___Rule][m:(_Manifold|_Atlas)]/; 
		$VersionNumber >= 6 :=
	Manipulate[Draw[Mapping[tr][m]], d]



End[];

Protect[Mapping, Sheaf, Breeding, Embed, Parameters, Manipulation];

EndPackage[];



