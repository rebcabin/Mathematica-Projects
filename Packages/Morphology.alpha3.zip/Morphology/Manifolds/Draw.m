(* :Title: Draw *)

(* :Context: Morphology`Manifolds`Draw` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: This package is a component of the directory 
	Morphology`Manifold, intended for internal use. 
	The drawing of manifolds is implemented. *)
    
(* :Keywords: manifold, atlas, vizualisation, drawing, graphics *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)
(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References: *)



BeginPackage["Morphology`Manifolds`Draw`",
    {"Morphology`Manifolds`",
     "Morphology`Manifolds`Datatypes`",
     "Morphology`SolidPlot`"
    }];
    
Raster2D::Usage = "";
Draw::Usage = "";
DrawingStyle::Usage = "";
PrependOptions::Usage = "";
AppendOptions::Usage = "";



Begin["`Private`"];

(* *** Drawing manifolds *** *)

(* Annex functions *)

(*  For transitional version, temporary use 
	of FilterOptions by Roman E. Maeder 
	from package Utilities`FilterOptions`
	instead of loading the package *)

FilterOptions[ command_Symbol, options___ ] :=
	FilterOptions[ First /@ Options[command], options ]

FilterOptions[ opts_List, options___ ] :=
	Sequence @@ Select[ Flatten[{options}], MemberQ[opts, First[#]]& ]



PrependOptions[Manifold[w___, old___Rule], new___Rule]:=Manifold[w, new, old]
AppendOptions[Manifold[w___, old___Rule], new___Rule]:=Manifold[w, old, new]



colorTypeQ[_GrayLevel | _RGBColor | _Hue | _CMYKColor] := True
colorTypeQ[___] := False

internalDisplayFunction[opt___]:=
	DisplayFunction/.{opt}/.(DisplayFunction->$DisplayFunction)
	
internalPlotStyle[opt___]:=
	Flatten[{PlotStyle/.{opt}/.(PlotStyle->{})}]
	
prependDirectives[(g:(Graphics|Graphics3D))[w:{__List},opt___], dir_List]:=
	g[Map[Join[dir,#]&, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w_List,opt___], dir_List]:=
	g[Join[dir, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w___], {dir___}]:=
	g[dir, w]
	
prependDirectives[(g:(Graphics|Graphics3D))[w:{__List},opt___], dir_]:=
	g[Map[Prepend[#, dir]&, w], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w_List,opt___], dir_]:=
	g[Prepend[w, dir], opt]
	
prependDirectives[(g:(Graphics|Graphics3D))[w___], dir_]:=
	g[dir, w]


	
(* Many - valued manifolds *)

Draw[Manifold[p_/;TensorRank[p] > 2, c___List], opt___] := 
  Draw[Manifold[Flatten[p, TensorRank[p] - 2], c], opt]



Draw[Manifold[p : {{_, _} ..}], opt___] :=
  Show[Graphics[Join[
  	internalPlotStyle[opt],
  	Map[Point, p]]
  ], FilterOptions[Graphics, opt],
	 PlotRange->All]
  
Draw[Manifold[p : {{_, _, _} ..}], opt___] := 
  Show[Graphics3D[Join[
  	internalPlotStyle[opt],
  	Map[Point, p]]
  ], FilterOptions[Graphics3D, opt],
	 PlotRange->All]
  
Draw[Manifold[p : {{_, _} ..}, d_List], opt___] :=
  ParametricPlot[p, d, Evaluate[FilterOptions[ParametricPlot, opt]]]
  
Draw[Manifold[p : {{_, _} ..}, d1_List, d2_List], opt___]/; 
	$VersionNumber < 6 := 
  SolidParametricPlot[p, d1, d2, FilterOptions[SolidParametricPlot, opt]]
  
Draw[Manifold[p : {{_, _} ..}, d1_List, d2_List], opt___]/; 
	$VersionNumber >= 6 := 
  ParametricPlot[p, d1, d2, Evaluate[FilterOptions[ParametricPlot, opt]]]
  
Draw[Manifold[p : {{_, _, _} ..}, d_List], opt___]/; 
	$VersionNumber < 6 :=
  Show[
  	prependDirectives[
  		ParametricPlot3D[p, d,  DisplayFunction -> Identity,
  			Evaluate[FilterOptions[ParametricPlot3D, opt]]
 	 	], internalPlotStyle[opt]
 	], DisplayFunction -> internalDisplayFunction[opt]
  ]
  
Draw[Manifold[p : {{_, _, _} ..}, d_List], opt___]/; 
	$VersionNumber >= 6 :=
  ParametricPlot3D[p, d, Evaluate[FilterOptions[ParametricPlot3D, opt]]]
  
Draw[Manifold[p : {{_, _, _} ..}, d1_List, d2_List], opt___] := 
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]
  
Draw[Manifold[p : {{_, _, _, _?colorTypeQ} ..}, d1_List, d2_List], opt___] :=
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]
  
Draw[Manifold[p : {{_, _, _} ..}, d1_List, d2_List, d3_List], opt___] := 
  SolidParametricPlot3D[p, d1, d2, d3, 
  	FilterOptions[SolidParametricPlot3D, opt]]
  
  

(* Standard manifolds *)

Draw[Manifold[p : {_, _}], opt___] :=
  Show[Graphics[Join[
  	internalPlotStyle[opt],
  	{Point[p]}
  ]], FilterOptions[Graphics, opt],
	  PlotRange->All]
  
Draw[Manifold[p : {_, _, _}], opt___] :=
  Show[Graphics3D[Join[
  	internalPlotStyle[opt],{Point[p]}
  ]], FilterOptions[Graphics3D, opt],
	  PlotRange->All]
  
Draw[Manifold[p : {_, _}, d_List], opt___] :=
  ParametricPlot[p, d, Evaluate[FilterOptions[ParametricPlot, opt]]]
  
Draw[Manifold[p : {_, _}, d1_List, d2_List], opt___]/; 
	$VersionNumber < 6 := 
  SolidParametricPlot[p, d1, d2, FilterOptions[SolidParametricPlot, opt]]

Draw[Manifold[p : {_, _}, d1_List, d2_List], opt___]/; 
	$VersionNumber >= 6 := 
  ParametricPlot[p, d1, d2, Evaluate[FilterOptions[ParametricPlot, opt]]]

Draw[Manifold[p : {_, _, _}, d_List], opt___]/; 
	$VersionNumber < 6 :=
  Show[
  	prependDirectives[
  		ParametricPlot3D[p, d,  DisplayFunction -> Identity,
  			Evaluate[FilterOptions[ParametricPlot3D, opt]]
 	 	], internalPlotStyle[opt]
 	], DisplayFunction -> internalDisplayFunction[opt]
  ]

Draw[Manifold[p : {_, _, _}, d_List], opt___]/; 
	$VersionNumber >= 6 :=
  ParametricPlot3D[p, d, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p : {_, _, _}, d1_List, d2_List], opt___]/; 
	$VersionNumber < 6 :=
  Show[
  	prependDirectives[
  		ParametricPlot3D[p, d1, d2,  DisplayFunction -> Identity,
  			Evaluate[FilterOptions[ParametricPlot3D, opt]]
 	 	], internalPlotStyle[opt]
 	], DisplayFunction -> internalDisplayFunction[opt]
  ]

Draw[Manifold[p : {_, _, _}, d1_List, d2_List], opt___]/; 
	$VersionNumber >= 6 :=
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p : {_, _, _, _?colorTypeQ}, d1_List, d2_List], opt___] := 
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p : {_, _, _}, d1_List, d2_List, d3_List], opt___] := 
  SolidParametricPlot3D[p, d1, d2, d3, 
  	FilterOptions[SolidParametricPlot3D, opt]]
  
  

(* Other forms *)

Draw[Manifold[p_, d : {t_, tmin_, _}], opt___] /; 
    MatchQ[p /. {t -> tmin}, {_, _}|{{_, _} ..}] :=
  ParametricPlot[p, d, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p_, d1 : {u_, umin_, _}, d2 : {v_, vmin_, _}], opt___] /; 
    (MatchQ[p /. {u -> umin, v -> vmin}, {_, _}|{{_, _} ..}] && 
	$VersionNumber < 6) := 
  SolidParametricPlot[p, d1, d2, FilterOptions[SolidParametricPlot, opt]]

Draw[Manifold[p_, d1 : {u_, umin_, _}, d2 : {v_, vmin_, _}], opt___] /; 
    (MatchQ[p /. {u -> umin, v -> vmin}, {_, _}|{{_, _} ..}] && 
	$VersionNumber >= 6) := 
 ParametricPlot[p, d1, d2, Evaluate[FilterOptions[ParametricPlot, opt]]]

Draw[Manifold[p_, d : {t_, tmin_, _}], opt___] /; 
    (MatchQ[p /. {t -> tmin}, {_, _, _}|{{_, _, _} ..}] && 
	$VersionNumber < 6) :=
  Show[
  	prependDirectives[
  		ParametricPlot3D[p, d,  DisplayFunction -> Identity,
  			Evaluate[FilterOptions[ParametricPlot3D, opt]]
 	 	], internalPlotStyle[opt]
 	], DisplayFunction -> internalDisplayFunction[opt]
  ]

Draw[Manifold[p_, d : {t_, tmin_, _}], opt___] /; 
    (MatchQ[p /. {t -> tmin}, {_, _, _}|{{_, _, _} ..}] && 
	$VersionNumber >= 6) :=
  ParametricPlot3D[p, d, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p_, d1 : {u_, umin_, _}, d2 : {v_, vmin_, _}], opt___] /; 
    MatchQ[p /. {u -> umin, v -> vmin}, {_, _, _}|{{_, _, _} ..}] := 
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p_, d1 : {u_, umin_, _}, d2 : {v_, vmin_, _}], opt___] /; 
    MatchQ[p /. {u -> umin, v -> vmin}, 
      {_, _, _, _?colorTypeQ}|{{_, _, _,___?colorTypeQ} ..}
    ] := 
  ParametricPlot3D[p, d1, d2, Evaluate[FilterOptions[ParametricPlot3D, opt]]]

Draw[Manifold[p_, 
  d1 : {u_, umin_, _}, d2 : {v_, vmin_, _}, d3 : {w_, wmin_, _}], opt___] /; 
  MatchQ[
    p /. {u -> umin, v -> vmin, w -> wmin}, 
    {_, _, _}|{{_, _, _} ..}
  ]:= 
  SolidParametricPlot3D[p, d1, d2, d3, 
  	FilterOptions[SolidParametricPlot3D, opt]]
  
  

(* DrawingStyle experimental *)

OKForDrawing[_Manifold]:=True
OKForDrawing[_Atlas]:=True
OKForDrawing[_DrawingStyle]:=True
OKForDrawing[___]:=False

Draw[DrawingStyle[m_Manifold, localOpt___], globalOpt___]:=
	Draw[m, localOpt, globalOpt]
	
Draw[DrawingStyle[a_Atlas, localOpt___], globalOpt___]:=
	Draw[a, localOpt, globalOpt]

Codomain[DrawingStyle[m_Manifold, localOpt___]]:= Codomain[m]

coDimension[Manifold[p_?VectorQ, ___]]:= Length[p]

coDimension[Manifold[p_ /; TensorRank[p] > 2, c___]] := 
 coDimension[Manifold[Flatten[p, TensorRank[p] - 2], c]]
 
coDimension[Manifold[p_, ___]]/;(TensorRank[p]==2):=Length[p[[1]]]
(* ajouter test == codims *)

coDimension[DrawingStyle[obj_, ___]]:=coDimension[obj]

coDimension[Atlas[a_, ___]]/;Apply[Equal, Map[coDimension, a]]:=
	coDimension[First[a]]


(* Auxiliary function for atlasses and graphic arrays *)
(* filtrer selon types et valeurs : opt repere ou opt obj
PlotPoints, PlotStyle... ImageSize...  *)

padOption[x_ -> opt:{{__} ..}, 2, n_]:=
	Map[Rule[x, #]&, PadRight[opt, n, opt], {2}]

padOption[x_ -> opt:{__}, 2, n_]:=
	Map[Rule[x, #]&, PadRight[{opt}, n, {opt}], {2}]

padOption[x_ -> opt_, 2, n_]:=
	Map[Rule[x, #]&, PadRight[{{opt}}, n, {{opt}}], {2}]

padOption[x_ -> {opt__}, 1, n_]:=
  Thread[Rule[x, PadRight[{opt}, n, {opt}]]]

padOption[x_ -> {}, _, n_]:= Sequence[]

padOption[x_ -> opt_, 1, n_]:=
	Thread[Rule[x, PadRight[{opt}, n, {opt}]]]

adHocTranspose[{}, {p_, q_}]:= Table[{}, {p},{q}]
adHocTranspose[{}, n_]:= Table[{},{n}]
adHocTranspose[m_?MatrixQ, _]:= Transpose[m]
adHocTranspose[m_/;ArrayDepth[m]==3, _]:= Transpose[m, {3,1,2}]



(* Atlases *)

Draw[Atlas[
	a : {__?OKForDrawing}], 
	preOpt___, optList:{___(*List*)}, postOpt___
	]/;And[
	  Length[a]==Length[optList],
	  Apply[Equal, Map[coDimension, a]]
	] := 
  Show[MapThread[
    Draw[
  	  #1, DisplayFunction -> Identity, 
      Apply[Sequence, #2], Apply[Sequence, #3], Apply[Sequence, #4]
    ] &, 
	{a, 
  	 adHocTranspose[Map[padOption[#, 1, Length[a]]&, {preOpt}], Length[a]], 
  	 Map[Flatten[{#}, 1]&, optList], 
  	 adHocTranspose[Map[padOption[#, 1, Length[a]]&, {postOpt}], Length[a]]
  	}], 
     DisplayFunction -> internalDisplayFunction[opt],
	 PlotRange->All
  ]


Draw[Atlas[a : {__?OKForDrawing}], opt___] /; 
    Apply[Equal, Map[coDimension, a]] := 
  Show[MapThread[
	  Draw[#, DisplayFunction -> Identity, ##2] &, 
	  {a, Apply[Sequence, Map[padOption[#, 1, Length[a]]&, {opt}]]}
	], 
    DisplayFunction -> internalDisplayFunction[opt],
	PlotRange->All
  ]
        
    

(* Arrays *) 

Draw[a : {__?OKForDrawing}, preOpt___, optList_List, postOpt___]/;
	(Length[a]==Length[optList]) := 
  Show[GraphicsArray[
   MapThread[
    Draw[#1, DisplayFunction -> Identity, 
      Apply[Sequence, #2], Apply[Sequence, #3], Apply[Sequence, #4]] &, 
  	{a, 
  	adHocTranspose[Map[padOption[#, 1, Length[a]]&, {preOpt}], Length[a]], 
  	Map[Flatten[{#}, 1]&, optList],
  	adHocTranspose[Map[padOption[#, 1, Length[a]]&, {postOpt}], Length[a]]
  	}
  	], GraphicsSpacing -> 
  		(GraphicsSpacing/.{preOpt, postOpt}/.Options[GraphicsArray])
  	], DisplayFunction -> internalDisplayFunction[preOpt, postOpt]]
    

Draw[a : {{__?OKForDrawing} ..}, preOpt___, optList:{{___}..}, postOpt___]/; 
	(Dimensions[a,2]==Dimensions[optList,2]) := 
  Show[GraphicsArray[
   MapThread[
    Draw[#1, DisplayFunction -> Identity, 
      Apply[Sequence, #2], Apply[Sequence, #3], Apply[Sequence, #4]] &, 
    {a,  adHocTranspose[
    	Map[padOption[#, 2, Dimensions[a]]&, {opt}], 
      Dimensions[a]], 
    Map[Flatten[{#}, 1]&, optList],
    adHocTranspose[
    	Map[padOption[#, 2, Dimensions[a]]&, {opt}], 
      Dimensions[a]]
    },2
    ], GraphicsSpacing -> 
  		(GraphicsSpacing/.{preOpt, postOpt}/.Options[GraphicsArray])
   ], DisplayFunction -> internalDisplayFunction[preOpt, postOpt]]
    

Draw[a : {__?OKForDrawing}, opt___] := 
  Show[GraphicsArray[MapThread[
  	Draw[#1, DisplayFunction -> Identity, Apply[Sequence, #2]] &, 
  	  {a, 
  	   adHocTranspose[Map[padOption[#, 1, Length[a]]&, {opt}], Length[a]]
  	  } 
  	], GraphicsSpacing -> 
  		(GraphicsSpacing/.{opt}/.Options[GraphicsArray])
  	], DisplayFunction -> internalDisplayFunction[opt]]
    

Draw[a : {{__?OKForDrawing} ..}, opt___] := 
  Show[GraphicsArray[
    MapThread[
      Draw[#, DisplayFunction -> Identity, Apply[Sequence, #2]] &, 
      {a, 
       adHocTranspose[
         Map[padOption[#, 2, Dimensions[a]]&, {opt}], 
         Dimensions[a]
       ]
      }, 2
    ], GraphicsSpacing -> 
  		(GraphicsSpacing/.{opt}/.Options[GraphicsArray])
    ], DisplayFunction -> internalDisplayFunction[opt]]



(* ** * Variants *** *)

(* Raster2D - with version 6, use MeshShading *)

Raster2D[mat_, Manifold[e_, {u_, umin_, umax_}, {v_, vmin_, vmax_}]]/;
 $VersionNumber < 6 := 
  Manifold[MapThread[
      Append, {Table[
          e /. Evaluate[
              Thread[Rule[{u, 
                    v}, {u, 
                      v} + {p, q}*{(umax - umin), (vmax - vmin)}/
                        Dimensions[mat]]]], 
          Evaluate[
            Apply[Sequence, Thread[List[{p, q}, 0, Dimensions[mat] - 1]]]]], 
        mat}, 2], 
    Apply[Sequence, 
      Transpose[{{u, v}, {umin, 
            vmin}, {umin, vmin} + {(umax - umin), (vmax - vmin)}/
              Dimensions[mat]}]]]



End[];

Protect[
	Raster2D, Draw, DrawingStyle, 
	PrependOptions, AppendOptions
];

EndPackage[];
