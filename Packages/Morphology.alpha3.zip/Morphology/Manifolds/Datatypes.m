(* :Title: Datatypes *)

(* :Context: Morphology`Manifolds`Datatypes` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is a component of the directory Morphology`Manifold,
    intended for internal use. The drawing of manifolds is defined. *)
    
(* :Keywords: data types, contexts *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions,version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)
(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References: *)



BeginPackage["Morphology`Manifolds`Datatypes`"];

(* Set up contexts for Manifold, Atlas, Domain, Codomain, Coordinates *)

Morphology`Manifolds`Manifold::Usage = "";
Morphology`Manifolds`Atlas::Usage = "";

Morphology`Manifolds`Domain::Usage = "";
Morphology`Manifolds`Codomain::Usage = "";
Morphology`Manifolds`Coordinates::Usage = "";



Begin["`Private`"];

End[];

EndPackage[];
