(* :Title: Mesher *)

(* :Context: Morphology`Mesher` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

	This package is a complementary component of the directory Morphology.
    A link with the IMTEK Mathematica supplement (IMS) is established. *)
    
(* :Keywords: mesh, mesher, finite elements *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* 	:Limitations: *)
(* 	:Requirements: *)
(* 	:Discussion: *)


(* :References and sources: 

	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 
	
	O. Rubenkonig, Z. Liu, J. Korvink: 
	Integrated Engineering Development Environment, 
	International Mathematica Symposium IMS'05, 2005, 
	https://internationalmathematicasymposium.org/IMS2005/ 
	
	O.Rubenkonig, J. Korvink, IMTEK Mathematica Supplement (IMS), 
	2002-2005, http://www.imtek.de/simulation/mathematica/IMSweb/ *)



BeginPackage["Morphology`Mesher`",
	{
    "Morphology`Manifolds`", 
    "Imtek`Graph`", 
    "Imtek`MeshElementLibrary`",
    "Imtek`Nodes`"
    }];

Off[General::"spell"];

ToImsNexus::Usage = "";


Begin["`Private`"];

numbering[m_][pt_, {i_, j_}] := imsMakeNode[m(i - 1) + j, pt]
numbering[m_, n_][pt_, {i_, j_, k_}] := 
  imsMakeNode[m*n(i - 1) + n(j - 1) + k, pt]


(* 2D case *)

ToImsNexus/:HoldPattern[ToImsNexus[
	m:Manifold[{_, _}, {u_, _, _}, {v_, _, _}], 
	{u_, p_}, {v_, q_}
	]]:= 
  With[{t = MapIndexed[numbering[q], First[Slice[m, {u, p}, {v, q}]], {2}]},
    imsMakeNexus[
      Union[Flatten[{First[t], Last[t], Take[t, All, 1], Take[t, All, -1]}]],
      Flatten[Drop[Drop[t, 1, 1], -1, -1], 1],
      Flatten[Table[
      	imsMakeQuadLinear1DOF[(q - 1)(i - 1) + j, 
      		{q(i - 1) + j, q i + j, q i + j + 1, q(i - 1) + j + 1}
      	], 
        {i, 1, p - 1}, {j, 1, q - 1}], 1]]
    ]


(* 3D case *)

ToImsNexus/:HoldPattern[ToImsNexus[
	m:Manifold[{_, _, _}, {u_, _, _}, {v_, _, _}, {w_, _, _}], 
    {u_, p_}, {v_, q_}, {w_, r_}
    ]]:= 
  With[
   {t = MapIndexed[
   		numbering[q, r], 
   		First[Slice[m, {u, p}, {v, q}, {w, r}]],
   		{3}]
   },
    imsMakeNexus[
      Union[Flatten[{
        First[t], 
       	Last[t], 
       	Take[t, All, All, 1], 
        Take[t, All, All, -1], 
        Take[t, All, 1, All], 
        Take[t, All, -1, All]
      }]], 
      Flatten[Drop[Drop[t, 1, 1, 1], -1, -1, -1]],
      Flatten[Table[
        imsMakeHexahedronLinear1DOF[
        	(q - 1)*(r - 1)(i - 1) + (r - 1)(j - 1) + k, 
            {
            q*r(i - 1) + r(j - 1) + k, 
            q*r(i - 1) + r(j - 1) + k + 1, 
            q*r(i - 1) + r*j + k + 1, 
            q*r(i - 1) + r*j + k,
            q*r*i + r(j - 1) + k, 
            q*r*i + r(j - 1) + k + 1, 
            q*r*i + r*j + k + 1,
            q*r*i + r*j + k
            }
         ], {i, 1, p - 1}, {j, 1, q - 1}, {k, 1, r - 1}
 		]]
      ]
    ]


End[];

On[General::"spell"];

Protect[ToImsNexus];

EndPackage[];
