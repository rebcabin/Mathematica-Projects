(* ::Package:: *)

(* :Title: Fields : differential geometry and tensor analysis *)

(* :Context: Morphology`Fields` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    It is dedicated to differential geometry and tensor (field) 
    analysis. *)
    
(* :Keywords: differential geometry, tensor, tensor analysis, 
	field, field analysis *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References:
 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 *)



BeginPackage["Morphology`Fields`", 
    {
    "Morphology`Manifolds`"
    }];

$SimplificationRules::Usage = "";

JacobianMatrix::Usage = "";
JacobianDet::Usage = "";
TangentManifold::Usage = "";
TangentBundle::Usage = "";

Low::Usage = "";
High::Usage = "";
Tensor::Usage = "";
Field::Usage = "";
TensorOrder::Usage = "";
Component::Usage = "";
Variances::Usage = "";
Symmetries::Usage = ""; (* experimental *)
AbridgedForm::Usage = ""; (* experimental *)
Contract::Usage = "";
Tensorial::Usage = "";
Interior::Usage = "";

Exterior::Usage = "";
ExteriorIndex::Usage = "";
Wedge::Usage = "";
DForm::Usage = "";

JacobianMinors::Usage = "";

Connection::Usage = "";
SetConnection::Usage = "";
RiemannConnection::Usage = "";
ChristoffelGamma::Usage = "";

Metric::Usage = "";
SetMetric::Usage = "";
EuclidMetric::Usage = "";
PoincareMetric::Usage = "";

CovariantD::Usage = "";
ExteriorD::Usage = "";

Moment::Usage = "";

Dirac::Usage = "";
MIntegrate::Usage = "";
(* Convolve::Usage = ""; *)
Convolution::Usage = "";



Begin["`Private`"];

$SimplificationRules = Simplify;



(* Tangent manifold *)

JacobianMatrix[f_, c_] := Outer[D, f, c]
JacobianDet[f_, c_] := Det[Outer[D, f, c]]

TangentManifold[m : Manifold[e_, __], pt_List] := 
  Manifold[(JacobianMatrix[e, Coordinates[m]] /. 
          Thread[Rule[Coordinates[m], pt]]).Map[Dt, Coordinates[m]], 
    Apply[Sequence, Map[Dt, Coordinates[m]]]]

TangentBundle[m : Manifold[e_, __]] := 
  Manifold[Dt[e], Join[Coordinates[m], Map[Dt, Coordinates[m]]]]



(* Tensorial operations on lists ; extension of Inner *)

updatePair[{i_,j_},{k_,l_}]/;j<k:={k-2,l-2}
updatePair[{i_,j_},{k_,l_}]/;k<j<l:={k-1,l-2}
updatePair[{i_,j_},{k_,l_}]/;l<j:={k-1,l-1}

updateAllPairs[{},{f_,v___}]:=updateAllPairs[{f},{v}]
updateAllPairs[{u___,c_},{f_,v___}]:=
  updateAllPairs[{u,c,updatePair[c,f]},Map[updatePair[c,#]&,{v}]]
updateAllPairs[w_,{}]:=w

contractPair[t_,c_,cf_]:=With[{dim=ArrayDepth[t]},
    Tr[Transpose[t,Ordering[Join[c,Delete[Range[dim],Map[List,c]]]]],
      MapThread[cf,{##},dim-2]&,2]
    ]

Contract[s__List,c_List,tf_:Times,cf_:Plus]:=Switch[c,
      _?(Not[Apply[Unequal,Flatten[#]]]&),
      "Error message: contraction indices",
      {},Outer[tf,s],
      {_Integer,_Integer},contractPair[Outer[tf,s],c,cf],
      {__List},
      Fold[contractPair[#1,#2,cf]&,Outer[tf,s],
        updateAllPairs[{},Sort[Map[Sort,c]]]]
      ]/;MatchQ[c,{{_Integer,_Integer}...}|{_Integer,_Integer}]
      


(* Tensor algebra *)

Tensor[t_, {}, ___]:= t (* scalar *)
      
Normal[Tensor[theList_, ___]]^:= theList

TensorOrder[Tensor[theList_, ___]]^:= ArrayDepth[theList]

Variances[Tensor[_, var_, ___]]^:= Flatten[{var}]

Symmetries[Tensor[_, _, s___]]^:= {s} (* experimental *)

Component[Tensor[t_, ___], index_]^:= Extract[t, index]

TableForm[Tensor[theList_, ___], opt___]^:= TableForm[theList, opt]



Tensor[t1_, variance_, s___]+Tensor[t2_, variance_, s___]^:=
  Tensor[t1+t2, variance, s] (* else message *)

k_*Tensor[t_, variance_, s___]^:=
	Tensor[k t, variance, s] (* else message *)



Tensorial[s__Tensor, c_List]/;And[
      Apply[Unequal,Flatten[c]],
      Apply[And,Map[#<=Apply[Plus,Map[TensorOrder,{s}]]&, Flatten[c]]]
      ]:=
  Tensor[
    Contract[Apply[Sequence, Map[First, {s}]] ,c],
    Delete[Apply[Join, Map[Variances, {s}]], Map[List, Flatten[c]]]
    ]
(* else "Error message: contraction indices"
+ test variances *)



(* Exterior operations *)

Exterior[v_, _, d_, n_]/;Not[
	(0 <= d <= n) && Length[Flatten[{v}]] == Binomial[n, d]
  ]:= "Error message ; incorrect dims" (* Message[...] *)
  
(* Exterior[e_?scalarQ, d_, n_]:= Exterior[{e}, d, n] *)

Exterior[v1_, variance_, d_, n_] + Exterior[v2_, variance_, d_, n_]^:=
  Exterior[v1+v2, variance, d, n] (* else message *)

k_ * Exterior[v_, variance_, d_, n_]^:=
  Exterior[k v, variance, d, n]
  
strictIndexCombinations[n_, ki_List]:=
  Select[
    Flatten[
      Outer[List, Apply[Sequence, Map[Subsets[Range[n],{#}]&, ki]], 1],
      Length[ki]-1
      ],
    Length[Apply[Union,#]]==Total[ki]&
  ]

toBasis[iList_]:= basis[Apply[Union, iList]]

ExteriorIndex[indexList_, n_]:=
  First[Position[Subsets[Range[n], {Length[indexList]}], indexList]]

exteriorComponent[ext_, indexList_, n_]:=
	Extract[ext, ExteriorIndex[indexList, n]]

mapper[w_, n_, p_][someStrictIndexCombination_]:=
  Signature[Apply[Join, someStrictIndexCombination]]*
    Apply[p,MapThread[
        exteriorComponent[#1, #2, n]&, {w, someStrictIndexCombination}]]*
    toBasis[someStrictIndexCombination]

SetAttributes[Wedge, {Flat, OneIdentity}]

Wedge[w__Exterior]/;And[
	Apply[SameQ,Map[{#[[2]],#[[4]]}&,{w}]],
	Total[Map[#[[3]]&,{w}]]>{w}[[1,4]]
      ]:= 0
      
Wedge[w__Exterior]/;Apply[SameQ, Map[{#[[2]],#[[4]]}&,{w}]]:=
  With[{n={w}[[1,4]], ki=Map[#[[3]]&,{w}]},
    Exterior[
      Map[
        Coefficient[
            Apply[Plus,
              Map[mapper[Map[First,{w}], n, Times],
                strictIndexCombinations[n, ki]]], #]&,
         Map[basis, Subsets[Range[n], {Total[ki]}]]
         ], 
       {w}[[1, 2]], 
       Total[ki], 
       n]
    ]

Dwedge[w__Exterior]/;Apply[SameQ,Map[{#[[2]],#[[4]]}&,{w}]]:=
  With[{n={w}[[1,4]],ki=Map[#[[3]]&,{w}]},
    Map[Coefficient[
          Apply[Plus,
            Map[mapper[Map[First,{w}], n, D],
              strictIndexCombinations[n, ki]]],#]&,
      Map[basis,Subsets[Range[n], {Total[ki]}]]]
    ]



(* Field analysis : tensors and differential forms *)

symbolQ[_Symbol]:=True
symbolQ[___]:=False

Normal[Field[theList_, ___]]^:= theList

TensorOrder[Field[theList_, ___]]^:= ArrayDepth[theList]

Variances[Field[_, var_, ___]]^:= Flatten[{var}]

Symmetries[Field[_, _, s___, _]]^:= {s} (* experimental *)

Domain[Field[___, m_]]^:= m

Codomain[Field[t_, var_, ___]]^:= Tensor[t, var] (* att contexts - common *)

Component[
	Field[t_, ___], 
	index_/;Apply[And, Map[IntegerQ, Flatten[index]]]
  ]^:=
  Extract[t, index]

Component[
	Field[t_, ___, m_], 
	index_/;Apply[And, Map[symbolQ, Flatten[index]]]
  ]^:=
  Extract[t, Map[Position[Coordinates[m],#][[1,1]]&, index,{-1}]]

AbridgedForm[Field[t_, var_, ___, m_]]^:= 
	Field[t, var, "\[SkeletonIndicator] Manifold \[SkeletonIndicator]"]

Attributes[CoordinateForm] = {HoldAll} ; (* experimental + private *)

CoordinateForm[Field[t_, var_, ___, m_]]^:= 
	Field[t, var, CoordinateSystem[m]]

TableForm[Field[theList_,___], opt___]^:= TableForm[theList, opt]



Field[t1_, var_, m_] + Field[t2_, var_, m_]^:= 
	Field[t1+t2, var, m] (* else message *)

k_ * Field[t_, var_, m_]^:= Field[k*t, var, m] (* else message *)



updateType[Tensor[t__], m_]:= Field[t, m]
updateType[s_, m_]:= Field[s, m]

Tensorial[s__Field, c_List]/;Apply[Equal, Map[Domain,{s}]]:=
  updateType[
	Tensorial[Apply[Sequence, Map[Tensor[#[[1]],#[[2]]]&,{s}]],c],  
	Domain[{s}[[1]]]
  ]
  (* else "Error message: unequal domains" *)
  (* to do : up to a coord renaming *)



(* Basic fields *)

(* Generalized jacobian *)

JacobianMinors[k_Integer][m_Manifold]/;0 < k <= Dim[m]:= (* else *)
  Map[MapAt[Map[$SimplificationRules,#]&, #, 1]&,
    Apply[
      Wedge,
      Subsets[Map[Exterior[#,High,1, Codim[m]]&,
          Transpose[JacobianMatrix[Codomain[m],Coordinates[m]]]],{k}],
      {1}]
  ]
          
          

(* Metric *)

$Metric = EuclidMetric;

SetMetric[metric_]:= (Clear[Metric]; $Metric = metric)

EuclidMetric[coord_List]:= IdentityMatrix[Length[coord]]

PoincareMetric[lambda_][{_, v_}]:= lambda^2/v^2 IdentityMatrix[2]

(* 
LorentzMetric[v_List, c_][coord_List]
LorentzMetric[v_, c_][coord_List]
ReverseLorentzMetric[v_List, c_][coord_List]
ReverseLorentzMetric[v_, c_][coord_List]
MinkowskiMetric[v_, c_][coord_List]
ReverseMinkowskiMetric[v_, c_][coord_List]
SchwartzshildMetric[coord_List]
*)


metricMatrix[m:Manifold[p_, c__]]:=
  With[{jac=JacobianMatrix[p, Coordinates[m]]},
    Map[$SimplificationRules,Transpose[jac].$Metric[p].jac,{2}]
  ]
(* test induced metric dim < *)


Metric[{Low, Low}][m_]:=
  Metric[{Low, Low}][m]=
  Field[metricMatrix[m],{Low, Low}, m]

Metric[{High, High}][m_]:=
  Metric[{High, High}][m]=
  Field[Inverse[metricMatrix[m]],{High, High}, m]

Metric[{Low, High}][m_]:=
  Metric[{Low, High}][m]=
    Field[IdentityMatrix[Length[Coordinates[m]]],{Low, High}, m]

Metric[{High, Low}][m_]:=
  Metric[{High, Low}][m]=
    Field[IdentityMatrix[Length[Coordinates[m]]],{High, Low}, m]



(* Connection - Christoffel *)

$Connection = RiemannConnection;

SetConnection[connection_]:= 
	(Clear[ChristoffelGamma]; $Connection = connection)

RiemannConnection[coord_List]:= 
  If[$Metric === EuclidMetric,
	With[{dim = Length[coord]}, Table[0, {dim}, {dim}, {dim}]],
	 Map[$SimplificationRules,
	   Dot[
	     Inverse[$Metric[coord]],
	     With[{t = Outer[D, $Metric[coord], coord]},
	       t + Transpose[t, {3, 2, 1}] - Transpose[t] ]
	   ]/2,
     {3}]
  ]
(* test no metric $Metric===Unevaluated[$Metric] *)



(* see induced connection dim < *)

(*	specific formula for standard connection 
	to avoid useless zero tensor product  *)

ChristoffelGamma[{High, Low, Low}][m:Manifold[p_, c__]]:=
  ChristoffelGamma[{High, Low, Low}][m] =
  Which[
  	(* euclidean case *)
   $Connection === RiemannConnection && 
   $Metric === EuclidMetric &&
   Dim[m]==Length[p],
    With[{
    	cod=Codomain[m], 
    	coord=Coordinates[m]
    	},
    Field[
      Map[$SimplificationRules,
        Dot[Inverse[JacobianMatrix[cod, coord]],
          Outer[D, cod, coord, coord]
        ],
      {3}],
    {High, Low, Low}, m]
    ],
     (* any connection *)
    Dim[m]==Length[p],
    With[{
    	cod=Codomain[m], 
    	coord=Coordinates[m], 
    	jac=JacobianMatrix[p,Coordinates[m]]
    	},
    Field[
      Map[$SimplificationRules,
        Dot[Inverse[JacobianMatrix[cod, coord]],
          (Outer[D, cod, coord, coord]+
          Contract[$Connection[coord], jac, jac, {{2, 4},{3, 6}}]
          )
        ],
      {3}],
    {High, Low, Low}, m]
    ],
    (* induced connection by metric in riemannian case *)
   $Metric=!=Unevaluated[$Metric] &&
   Dim[m] < Length[p],
   With[{
   		coord=Coordinates[m], 
   		g=Normal[Metric[{Low, Low}][m]]
   		},
     Map[$SimplificationRules,
	   Dot[
	     Inverse[g],
	     With[{t = Outer[D, g, coord]},
	       t + Transpose[t, {3, 2, 1}] - Transpose[t] ]
	   ]/2,
     {3}]
   ]
  ]
(* else *)
      


(* Differential operators *)

scalarQ[_List]:=False
(* scalarQ[_Tensor]:=False *)
scalarQ[_]:=True

CovariantD[someField_Field]:= CovariantD[someField, 1]

CovariantD[someField_Field, 0]:= someField

CovariantD[Field[t_?scalarQ, ___, m_Manifold], 1]:= 
  Field[Map[D[t, #]&, Coordinates[m]], {Low}, m]
  (* valid with or without {} for variance *)

CovariantD[someField:Field[t_, var_, m_], 1]:=
  MapAt[Map[$SimplificationRules, #, {ArrayDepth[t]}]&,
   Field[Outer[D, t, Coordinates[m]], Flatten[{var, Low}], m] +
    Apply[Plus,
      Map[Tensorial[ChristoffelGamma[{High, Low, Low}][m], 
      		someField, {2, #}]&,
        3 + Flatten[Position[Flatten[{var}], High]]]] -
    Apply[Plus,
      Map[Tensorial[ChristoffelGamma[{High, Low, Low}][m], 
      		someField, {1, #}]&,
        3 + Flatten[Position[Flatten[{var}], Low]]]],
  1]

CovariantD[someField_, n_]:= Nest[CovariantD[#,1]&, someField, n]



(* Differential forms *)

DForm[e_, d_, m_]/;Not[
	(0 <= d <= Dim[m]) && Length[Flatten[{e}]] == Binomial[Dim[m], d]
  ]:= "Error message ; incorrect dims" (* Message[...] *)
  
DForm[e_?scalarQ, d_, m_]:= DForm[{e}, d, m]

Plus[HoldPattern[DForm[v1_, d_, m_]], HoldPattern[DForm[v2_, d_, m_]]]^:= 
	DForm[v1+v2, d, m]  (* else message *)

k_ * HoldPattern[DForm[v_, d_, m_]]^:= DForm[k v, d, m] 

toExterior[HoldPattern[DForm[e_, d_, m_]]]:= Exterior[e, Low, d, Dim[m]]
toDForm[Exterior[e_, Low, d_, _], m_]:= DForm[e, d, m]

Wedge[w__DForm]/;Apply[Equal, Map[Last,{w}]]:=
  toDForm[Wedge[Apply[Sequence, Map[toExterior,{w}]]], Last[{w}[[1]]]]
  
  
ExteriorD[HoldPattern[DForm[e_, d_, m_]]]/;d==Dim[m]:= 0

ExteriorD[HoldPattern[DForm[e_, d_, m_]]]/;d<Dim[m]:=
  DForm[Dwedge[Exterior[e, Low, d, Length[Coordinates[m]]],
      Exterior[Coordinates[m], Low, 1, Length[Coordinates[m]]]], d+1, m]



(* Integration *)

Integrate[DForm[e_, d_, m_]]/;d==Dim[c]^:= Integrate[e, Domain[m]]

Integrate[DForm[e_, d_, carrier_], m:Manifold[pr_, dom___]]/;
    Dim[carrier]==Codim[m]&&d==Dim[m]^:=
  Integrate[(e/.Thread[Coordinates[carrier]->pr]).Map[
    JacobianDet[#, Coordinates[m]]&,
    Subsets[pr, {Length[Coordinates[m]]}]],
    dom]



Moment[0][df_DForm]:=Integrate[df]

Moment[0][df_DForm, m_Manifold]:=Integrate[df, m]

Moment[n_][DForm[e_, d_, c_]]:=
  Integrate[Outer[Times, e, Apply[Sequence,Table[Coordinates[c], {n}]]], c]

Moment[n_][DForm[e_, d_, c_], m:Manifold[pr_, dom___]]:=
  Integrate[
    Outer[Times,{(e/.Thread[Coordinates[c]->pr]).Map[
            JacobianDet[#, Coordinates[m]]&,
            Subsets[pr, {Length[Coordinates[m]]}] ]},
      Apply[Sequence, Table[pr, {n}]]],dom]



(* obsolete definitions

SetAttributes[CovariantD, HoldRest]

CovariantD[scalar_, cs_[coord_]/;CoordinateSystemQ[cs[coord]]]:=
	Map[D[scalar,#]&,coord]

CovariantD[scalar_*Dirac[m_][v_]]/;Apply[And,Map[FreeQ[scalar,#]& ,v]]:=
  Map[D[scalar,#]&,Coordinates[m]]*DiracDelta[m][v]



(* Differential forms *)

exteriorBasis[w__List,n_]:=
  Apply[Wedge,Subsets[w,{n}],1]/.{Wedge[v_]:>v,Wedge[]:>Sequence[]}
Format[DForm[w_, c_List, 0]]:= w
Format[DForm[w_, c_, n_]]:= w.exteriorBasis[Map[Dt, c], n]
 
end of obsolete definitions 
*)


(* DiracDelta and fields *)

(* experimental *)

SimplifyDirac[
    alpha_*Dirac[m:Manifold[p_,c___]][var_]]:=
  (alpha/.Thread[var->p])*Dirac[m][var]
SimplifyDirac[x_]:=x
    
MIntegrate[(alpha_:1)*Dirac[m:Manifold[p_,c___]][var_],opt___]/;
    Apply[Or,Map[MemberQ[alpha,#,Infinity]& ,var]]:= 
  Integrate[JacobianDeterminant[p,Coordinates[m]]*
  SimplifyDirac[alpha*Dirac[m][var]],c,opt]
  
MIntegrate[(alpha_:1)*Dirac[m:Manifold[p_,c___]][var_],opt___]:= 
  Integrate[JacobianDeterminant[p,Coordinates[m]]*
  alpha*Dirac[m][var],c,opt]


  
(* Convolve[kernel_,(alpha_:1)*Dirac[Manifold[p_,c___]][var_],opt___]/;
    Apply[And,Map[FreeQ[alpha,#]& ,var]]:=
  Integrate[(kernel/.Thread[var->(var-p)])*alpha,c,opt] *)
  
(* revoir *)

Convolution[kernel_,(alpha_:1)*Dirac[Manifold[p_,c___]],var_,opt___Rule]/;
    Apply[And,Map[FreeQ[alpha,#]& ,var]]:=
    Integrate[kernel[var-p]*alpha,c,opt]


 
End[];

EndPackage[];




