BrowserCategory["Morphology", None,
  {
   	Item["Welcome", "Welcome.nb", CopyTag->None],
    BrowserCategory["About", "About", 
   		{Item["Licence", "Licence.nb", CopyTag->None]
  		}],
  	BrowserCategory["Tutorial", "Tutorial", 
   		{
   		Item["Overview", "Overview.nb", CopyTag->None],
   		Item["Introduction", "Introduction.nb", CopyTag->None],
   		Item["Data structure", "Data structure.nb", CopyTag->None],
   		Item["Drawing", "Drawing.nb", CopyTag->None],
   		Item["Primitives", "Primitives.nb", CopyTag->None],
		Item["Generators", "Generators.nb", CopyTag->None],
		Item["Operations", "Operations.nb", CopyTag->None],
   		Item["Vector Functions", "VectorFunctions.nb", CopyTag->None],
   		Item["Coordinates", "Coordinates.nb", CopyTag->None],
		Item["Mappings", "Mappings.nb", CopyTag->None],
   		Item["Transformations", "Transformations.nb", CopyTag->None],
   		Item["TransformationsBis", "TransformationsBis.nb", CopyTag->None],
   		Item["Extrusions", "Extrusions.nb", CopyTag->None],
   		Item["Duplications", "Duplications.nb", CopyTag->None],
   		Item["Embeddings", "Embeddings.nb", CopyTag->None],
   		Item["Animations", "Animations.nb", CopyTag->None],
   		Item["Homotopy", "Homotopy.nb", CopyTag->None],
   		Item["Shapes", "Shapes.nb", CopyTag->None],
  		Item["Field Analysis", "FieldAnalysis.nb", CopyTag->None],
  		Item[Delimiter],
  		Item["Fractals", "Fractals.nb", CopyTag->None],
    	Item["Mesher", "Mesher.nb", CopyTag->None],
  		Item[Delimiter],
  		Item["SolidPlot", "SolidPlot.nb", CopyTag->None],
   		Item["Utilities", "Utilities.nb", CopyTag->None],
   		Item[Delimiter],
   		Item["References", "References.nb", CopyTag->None]
  		}],
  	BrowserCategory["Examples", "Examples", 
   		{
   		Item["Minimal Surfaces", "MinimalSurfaces.nb", CopyTag->None],
   		Item["Adaptive Plotting", "AdaptivePlotting.nb", CopyTag->None],
   		Item["Higher Dimensions", "HigherDimensions.nb", CopyTag->None],
   		Item["Geodesics", "Geodesics.nb", CopyTag->None],
   		Item["Continuum Physics", "ContinuumPhysics.nb", CopyTag->None]
  		}],
  	BrowserCategory["Index", "Index", 
   		{
   		}]
}]




