(* :Title: Shapes *)

(* :Context: Morphology`Shapes` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    Common and less common shapes are defined as transformations. *)
    
(* :Keywords: shape, shape function, 
	primitive manifold, transformation *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References:
 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 
	
	C. H. Edwards: Twisted Tubes, 
	The Mathematica Journal, 3(1), 10-13. *)



BeginPackage["Morphology`Shapes`",
    {"Morphology`Manifolds`"}];

Annular::Usage="";
Helicoidal::Usage="";

Cycloidal::Usage="";
Trochoidal::Usage="";
EpiCycloidal::Usage="";
HypoCycloidal::Usage="";

Epicyclic::Usage="";
Lissajous::Usage="";
Moebius::Usage = "";

TwistedTube::Usage="";
Conchoid::Usage="";



Begin["`Private`"];



Annular[r_][{rho_, theta_, phi_}]:= 
	{(r + rho Cos[phi]) Cos[theta], 
	 (r + rho Cos[phi]) Sin[theta], 
	 rho Sin[phi]}

Helicoidal[s_][{r_, theta_, h_}]:=
	{r Cos[theta],
	 r Sin[theta],
	 s*theta/2/Pi + h
	}



(* t ou {t} ? *)

Cycloidal[{a_, b_}][{t_}]:= a{t,1}-b{Sin[t], Cos[t]}
Cycloidal[{t_}]:= {t-Sin[t], 1-Cos[t]}

Cycloidal[{a_, b_}][t_]:= a{t,1}-b{Sin[t], Cos[t]}
Cycloidal[t_]:= {t-Sin[t], 1-Cos[t]}

Trochoidal[r_][{t_}]:={t-r Sin[t], 1-r Cos[t]}

Trochoidal[r_][t_]:={t-r Sin[t], 1-r Cos[t]}

EpiCycloidal[R_,r_][{t_}]:=(1+R){Cos[t],Sin[t]}+r{Cos[t+t/r],Sin[t+t/r]}
HypoCycloidal[R_,r_][{t_}]:=(1-R){Cos[t],Sin[t]}+r{Cos[t+t/r],Sin[t+t/r]}

EpiCycloidal[R_,r_][t_]:=(1+R){Cos[t],Sin[t]}+r{Cos[t+t/r],Sin[t+t/r]}
HypoCycloidal[R_,r_][t_]:=(1-R){Cos[t],Sin[t]}+r{Cos[t+t/r],Sin[t+t/r]}



auxiliary[{r_, w_, phi_:0}, t_]:= r Cos[w t + phi]

Epicyclic[p_List][{t_}]:= Total[Map[auxiliary[#, t]&, p]]

Epicyclic[p_List][t_]:= Total[Map[auxiliary[#, t]&, p]]



Lissajous[s_List,phi_:0][{t_}]:= Sin[s*t+phi]

Lissajous[s_List,phi_:0][t_]:= Sin[s*t+phi]



Moebius[R_][{r_, theta_, h_:0}] := 
	{(R + r Cos[theta/2] + h Sin[theta/2]) Cos[theta], 
	 (R + r Cos[theta/2] + h Sin[theta/2]) Sin[theta], 
	  r Sin[theta/2] - h Cos[theta/2]}



TwistedTube[
	Manifold[{x_,y_}, dt_],
    dTheta:{theta_, thetamin_:0, thetamax_:(2 Pi)}, 
    r_, twist_, n_:1]:=
  Manifold[
	{0,0, y Cos[twist theta]+ x Sin[twist theta]} + 
    (r+x Cos[twist theta]- y Sin[twist theta]){Cos[theta], Sin[theta], 0},
    dt, dTheta
  ]

(* revoir *)
    
Conchoid[a_,b_,c_,n_]:=
	Manifold[a(1-v/2/Pi){(1+Cos[u])Cos[n v],(1+Cos[u])Sin[n v],Sin[u]}+
		{c Cos[n v], c Sin[n v], b v /2/Pi},{u,0,2 Pi},{v,0,2 Pi}]
    


End[];

Protect[Annular, Helicoidal, 
	Cycloidal, Trochoidal, EpiCycloidal, HypoCycloidal, 
	Epicyclic, Lissajous, Moebius, TwistedTube, Conchoid
	];

EndPackage[];
