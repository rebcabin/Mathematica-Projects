(* :Title: Graphic transformations *)

(* :Context: Morphology`Graphics` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    Graphic transformations are defined. *)
    
(* :Keywords: graphics, transformation *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* :Limitations: *)
(* :Requirements: *)
(* :Discussion: *)

(* :References: *)



BeginPackage["Morphology`Graphics`"];

Transform::Usage = "";



Begin["`Private`"];



(* ***  Application of affine transformations to graphics  *** *)

Transform[(_Graphics|_Graphics3D)[g_], tr_]:= Map[Transform[#, tr]&, g]
Transform[w_List, tr_]:= Map[Transform[#, tr]&, w]

Transform[Point[s:{__List}], tr_]:= Point[Map[tr, s]]
Transform[Point[pt_], tr_]:= Point[tr[pt]]
Transform[Line[s_], tr_]:= Line[Map[tr,s]]
Transform[Polygon[s_], tr_]:= Polygon[Map[tr,s]]
Transform[Text[txt_, pt_, w___], tr_]:= Text[txt, tr[pt], w]

(* Only translation or dilation *)

Transform[Rectangle[u_, v_, w___], tr_]:= Rectangle[tr[u], tr[v], w]
Transform[Cuboid[u_], tr_]:= Cuboid[tr[u]]
Transform[Cuboid[u_, v_], tr_]:= Cuboid[tr[u], tr[v]]
Transform[Raster[m_, {u_, v_}], tr_]:= Raster[m,{tr[u], tr[v]}]
Transform[RasterArray[m_, {u_, v_}], tr_]:= RasterArray[m,{tr[u], tr[v]}]

(* Specific rules *)

(*
Circle
Disk
Scaled
Offset
*)

(* Other objects: directives... *)

Transform[obj_, _]:= obj



End[];

On[General::"spell1"];

Protect[Transform];

EndPackage[];

