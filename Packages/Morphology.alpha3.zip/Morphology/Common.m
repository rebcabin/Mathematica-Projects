(* :Title: Common *)

(* :Context: Morphology`Common` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 
    This package is a component of the directory Morphology,
    intended for internal use. Vector functions abd function 
    systems are defined. *)
    
(* :Keywords: vector functions, function systems *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL 

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 
	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References: *)



BeginPackage["Morphology`Common`"];

VectorFunction::Usage="";
FunctionSystem::Usage="";
VectorFunctionSystem::Usage="";



Begin["`Private`"];

(* *** Vector pure function *** *)

SetAttributes[VectorFunction, HoldRest];

VectorFunction[w_?VectorQ, expr_]/;
	FreeQ[Hold[expr], VectorFunction|Function]:=
  ReleaseHold[
    Function[Evaluate[expr/.
        Thread[Rule[w, Array[Function[i, Hold[#[[i]]]], Length[w]]]]
    ]]
  ]

(* Experimental; nested vector functions; avoid capture *) 

vFunction[w_?VectorQ, expr_]:=
  ReleaseHold[
    Function[v, Evaluate[expr/.
      Thread[Rule[w, Array[Function[i, Hold[v[[i]]]], Length[w]]]]
    ]]/.v$->Unique[]
  ]

VectorFunction[w_?VectorQ,expr_]:=
  ReleaseHold[
    Function[v, Evaluate[
      ReleaseHold[Hold[expr] /. VectorFunction -> vFunction]/.
      Thread[Rule[w, Array[Function[i, Hold[v[[i]]]], Length[w]]]]
    ]]/.v$->Unique[]
  ]

VectorFunction[expr_]:= Function[expr]



(* *** Function systems *** *)

SetAttributes[FunctionSystem, HoldRest];

FunctionSystem[flist_List][var___]:= Through[flist[var]]

FunctionSystem[var_List, flist_List]:=
  FunctionSystem[ReleaseHold[
    Map[Function,
    	(Hold[flist]/.Thread[Rule[var,Array[Slot,Length[var]]]]), 
    	{2}
    ]
  ]]

FunctionSystem[var_, flist_List]:=
  FunctionSystem[ReleaseHold[
  	Map[Function,(Hold[flist]/.var -> Slot[1]), {2}]
  ]]

SetAttributes[VectorFunctionSystem, HoldRest];

VectorFunctionSystem[var_List, flist_List]:=
  FunctionSystem[ReleaseHold[
  	Map[VectorFunction[var, #]&, Hold[flist],{2}]
  ]]



End[];

EndPackage[];
