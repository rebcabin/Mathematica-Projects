(* :Title: Morphology *)

(* :Context: Morphology`Master` *)

(* :Author: Remi Y. Barrere, rbarrere@ens2m.fr 

	pro: 26 chemin de l'Epitaphe, F-25000 Besancon, France
	perso: 13 rue Antide-Thouret, F-25000 Besancon, France *)

(* :Summary: 

    This package is a component of the directory Morphology.
    It is simply intended to load the whole directory. *)
    
(* :Keywords: morphology, shape, form, field, 
	CAD, shape design, form synthesis *)
	
(* :Package Version: 0.3 alpha *)

(* :Mathematica Version: 5.2 and 6.0 *)

(* :Copyright: (C) 2006  Remi Y. Barrere  GNU LGPL

	This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General 
    Public License along with this library; if not, write to 
    the Free Software Foundation, Inc., 
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA *)

(* :History: 

	2006: first experimental version
	2007: alpha versions, version 5
	2008: alpha versions, version 6 *)
	
(* :Comments: None *)

(* Limitations: *)
(* Requirements: *)
(* Discussion: *)

(* :References:
 
	R. Barrere: An Algorithmic Approach to Manifolds, 
	International Mathematica Symposium IMS'06, 2006 *)



BeginPackage["Morphology`Master`",
    {
    "Morphology`Manifolds`",
    "Morphology`Fields`",
    "Morphology`Shapes`",
    "Morphology`Fractals`",
    "Morphology`PhasePortraits`"
    } (*
     Loaded by manifolds:
    "Morphology`Transformations`",
    "Morphology`Coordinates`"
     
     Directory Manifolds
     
     Loaded by Draw:
    "Morphology`SolidPlot`" 
    *) ];

(*	This package is only intended for loading 
	the whole directory about manifolds.
*)

EndPackage[];

